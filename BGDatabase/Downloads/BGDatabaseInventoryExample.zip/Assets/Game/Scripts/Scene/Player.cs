﻿using System.Collections;
using BansheeGz.BGDatabase;
using BansheeGz.BGDatabase.Example;
using UnityEngine;
using UnityEngine.SceneManagement;

//attach it to a player
public class Player : DbGoPlayer, BGAddonSaveLoad.BeforeSaveReciever
{
    public static Player Instance;

    [SerializeField] private Camera mainCamera;

    public static DbPlayer Default => DbPlayer.GetEntity(0);

    public Camera Camera => mainCamera;

    public override void Awake()
    {
        Instance = this;
        transform.position = f_position;
        transform.rotation = f_rotation;
        StartCoroutine(EnableController());
    }

    private IEnumerator EnableController()
    {
        //have no idea why it's not working with Save/Load
        yield return null;
        GetComponent<BGFirstPersonController>().enabled = true;        
    }

    public static bool IsPlayer(GameObject go)
    {
        return "Player".Equals(go.tag);
    }

    public void OnBeforeSave()
    {
        f_scene = SceneManager.GetActiveScene().name;
        f_position = transform.position;
        f_rotation = transform.rotation;
    }
}