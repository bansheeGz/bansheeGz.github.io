﻿using UnityEngine;
using UnityEngine.UI;

//abstract slot which updates item icon and amount
public class SlotAbstract
{
    private readonly Image itemIcon;
    private readonly Image amountIcon;
    private readonly Text amountText;

    public SlotAbstract(Image itemIcon, Image amountIcon, Text amountText)
    {
        this.itemIcon = itemIcon;
        this.amountIcon = amountIcon;
        this.amountText = amountText;
    }

    public void UpdateUi(DbItem item, int amount)
    {
        if (item == null)
        {
            itemIcon.sprite = null;
            itemIcon.color = Color.clear;
            UpdateAmount(0);
        }
        else
        {
            itemIcon.sprite = item.f_icon;
            itemIcon.color = Color.white;
            UpdateAmount(amount);
        }
    }
    private void UpdateAmount(int amount)
    {
        if (amount < 2)
        {
            amountIcon.gameObject.SetActive(false);
            amountText.text = "";
        }
        else
        {
            amountIcon.gameObject.SetActive(true);
            amountText.text = "" + amount;
        }
    }
}
