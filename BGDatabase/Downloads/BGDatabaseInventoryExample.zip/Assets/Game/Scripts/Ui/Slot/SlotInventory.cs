﻿using System.Collections;
using System.Collections.Generic;
using BansheeGz.BGDatabase;
using UnityEngine;
using UnityEngine.UI;

//basic inventory slot
public class SlotInventory : DbGoInventory, UiManager.IUpdatableUi
{
    //serializable
    public Image itemIcon;
    public Image amountIcon;
    public Text amountText;
    
    //equipped 
    public Image equippedIcon;

    //non serializable
    private SlotAbstract abstractSlot;

    public override void EntityChanged()
    {
        UpdateUi();
    }

    public virtual void UpdateUi()
    {
        Utils.Assign(ref abstractSlot, () => new SlotAbstract(itemIcon, amountIcon, amountText));
        if (Entity == null)
        {
            abstractSlot.UpdateUi(null, 0);
            equippedIcon.color = Color.clear;
        }
        else
        {
            abstractSlot.UpdateUi(f_item, f_amount);
            equippedIcon.color = f_item != null && (Equals(Player.Default.f_weapon, Entity) || Equals(Player.Default.f_armor, Entity)) ? Color.white : Color.clear;
        }
       
    }
}