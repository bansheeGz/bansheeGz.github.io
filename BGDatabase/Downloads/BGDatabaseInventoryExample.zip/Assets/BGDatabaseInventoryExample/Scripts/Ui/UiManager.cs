﻿using System;
using System.Collections;
using System.Collections.Generic;
using BansheeGz.BGDatabase;
using BansheeGz.BGDatabase.Example;
using UnityEngine;
using UnityEngine.UI;

//UI and Input stuff
public class UiManager : MonoBehaviour
{
    private static UiManager instance;
    private readonly Dictionary<Type, IWindow> type2Window = new Dictionary<Type, IWindow>();

    //serializable 
    [SerializeField] private Texture2D cursor;

    //not serializable
    private IWindow openedWindow;
    private GameMenu gameMenu;
    
    // ================================================= Properties
    private bool PlayerControllerEnabled
    {
        set
        {
            var fpsController = Player.Instance.GetComponent<BGFirstPersonController>();
            fpsController.enabled = value;
            fpsController.MMouseLook.SetCursorLock(value);
        }
    }

    // ================================================= Unity callbacks
    private void Start()
    {
        instance = this;

        //gather all forms
        foreach (var child in transform)
        {
            var childGo = ((Component) child).gameObject;

            var menu = childGo.GetComponent<GameMenu>();
            if (menu != null)
            {
                gameMenu = menu;
                gameMenu.gameObject.SetActive(false);
                continue;
            }
            
            var window = childGo.GetComponent(typeof(IWindow));
            if (window == null) continue;


            childGo.SetActive(false);
            type2Window[window.GetType()] = (IWindow) window;
        }

        //set cursor
        Cursor.SetCursor(cursor, Vector2.zero, CursorMode.Auto);
    }

    private void Update()
    {
        if (openedWindow != null)
        {
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                //close active form
                PlayerControllerEnabled = true;
                ((Component) openedWindow).gameObject.SetActive(false);
                openedWindow = null;
            }
        }
        else
        {
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                gameMenu.gameObject.SetActive(!gameMenu.gameObject.activeSelf);
                PlayerControllerEnabled = !gameMenu.gameObject.activeSelf;
            }
            if (Input.GetKeyDown(KeyCode.I))
            {
                //open inventory
                Open<WindowEquip>();
            }
        }
    }

    // ================================================= Methods
    private T GetWindow<T>() where T : Component, IWindow
    {
        return (T) type2Window[typeof(T)];
    }

    private T OpenWindow<T>() where T : Component, IWindow
    {
        var window = GetWindow<T>();
        foreach (var aWindow in type2Window.Values)
        {
            ((Component) aWindow).gameObject.SetActive(ReferenceEquals(window, aWindow));
        }

        GetWindow<WindowPopup>().Popup = null;
        PlayerControllerEnabled = false;
        openedWindow = window;
        return window;
    }


    // ================================================= Static
    public static T Open<T>() where T : Component, IWindow
    {
        return instance.OpenWindow<T>();
    }

    public static T Get<T>() where T : Component, IWindow
    {
        return instance.GetWindow<T>();
    }

    public static bool FormIsOpened
    {
        get { return instance != null && instance.openedWindow != null; }
    }

    public static void ShowAlert(string message)
    {
        Get<WindowAlert>().Show(message);
    }

    // ================================================= Nested interfaces
    //window
    public interface IWindow
    {
    }

    //Something, that has UI and can update this UI 
    public interface IUpdatableUi
    {
        void UpdateUi();
    }
}