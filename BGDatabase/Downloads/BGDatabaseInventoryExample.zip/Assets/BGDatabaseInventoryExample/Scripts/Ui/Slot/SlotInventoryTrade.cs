using UnityEngine.EventSystems;
using UnityEngine.UI;

//slot for inventory while trading
public class SlotInventoryTrade : SlotInventory, IPointerDownHandler
{
    //serializable
    public Image priceIcon;
    public Text priceText;

    //not serializable
    private DbTrader trader;
    public DbTrader Trader
    {
        set { trader = value; }
    }
    
    //this is a sell price for a player
    private int Price
    {
        get
        {
            var basePrice = f_item.f_price;
            var tradeLevel = DbAbility.GetEntity("Trade").f_level;
            //we assume 5 is max level for trade
            return basePrice - basePrice / 10 * (5-tradeLevel);
        }
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        if (Entity == null || f_item == null) return;

        var itemToSell = f_item;

        if (trader.f_gold < Price)
        {
            UiManager.ShowAlert("Trader does not have enough gold");
            return;
        }

        if (new TraderContainer(trader).TryToAdd(itemToSell))
        {
            Player.Default.f_gold += Price;
            trader.f_gold -= Price;
            if (f_amount > 1) f_amount -= 1;
            else
            {
                f_item = null;
                f_amount = 0;
            }
        }
        else UiManager.ShowAlert("Trader inventory is full");
    }

    public override void UpdateUi()
    {
        base.UpdateUi();

        if (Entity == null || f_item == null)
        {
            priceIcon.gameObject.SetActive(false);
            priceText.text = "";
        }
        else
        {
            priceIcon.gameObject.SetActive(true);
            priceText.text = "" + Price;
        }
    }
}