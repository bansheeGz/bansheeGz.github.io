using UnityEngine.EventSystems;

//slot for inventory while picking items from a chest
public class SlotInventoryEquip : SlotInventory, IPointerDownHandler
 {
     public void OnPointerDown(PointerEventData eventData)
     {
         if (f_item == null || f_item.f_type==null) return;
 
         switch (f_item.f_type.Index)
         {
             case 0:
             {
                 //weapon
                 Player.Default.f_weapon = (DbInventory) Entity;
                 break;
             }
             case 1:
             {
                 //armor
                 Player.Default.f_armor = (DbInventory) Entity;
                 break;
             }
                 
         }
     }
     
     
 }