using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

//slot for a trader
public class SlotTrade : DbGoTraderItems, IPointerDownHandler, UiManager.IUpdatableUi
{
    public Image itemIcon;
    public Image amountIcon;
    public Text amountText;

    public Image priceIcon;
    public Text priceText;

    private SlotAbstract abstractSlot;

    //this is a buy price for a player
    private int Price
    {
        get
        {
            var basePrice = f_item.f_price;
            var tradeLevel = DbAbility.GetEntity("Trade").f_level;
            //we assume 5- is a max level for trade
            return basePrice + basePrice / 10 * (5 - tradeLevel);
        }
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        if (Entity == null || f_item == null) return;

        var traderItem = (DbTraderItems) Entity;
        var itemToAdd = f_item;

        if (Price > Player.Default.f_gold)
        {
            UiManager.ShowAlert("You do not have enough gold");
            return;
        }
        
        var leftAmount = new InventoryContainer().TryToAdd(itemToAdd, 1);

        if (leftAmount == 0)
        {
            Player.Default.f_gold -= Price;
            f_Trader.f_gold += Price;
            if (traderItem.f_amount <= 1) traderItem.Delete();
            else traderItem.f_amount -= 1;
        }
        else UiManager.ShowAlert("Inventory is full");
    }

    public void UpdateUi()
    {
        Utils.Assign(ref abstractSlot, () => new SlotAbstract(itemIcon, amountIcon, amountText));
        if (Entity == null || f_item == null)
        {
            abstractSlot.UpdateUi(null, 0);
            priceIcon.gameObject.SetActive(false);
        }
        else
        {
            abstractSlot.UpdateUi(f_item, f_amount);
            priceIcon.gameObject.SetActive(true);
            priceText.text = "" + Price;
        }
    }
}