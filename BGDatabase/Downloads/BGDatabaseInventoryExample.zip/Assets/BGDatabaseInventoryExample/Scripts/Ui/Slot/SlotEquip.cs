using UnityEngine.EventSystems;

//slot for inventory while equipment  
public class SlotEquip : DbGoItemType, IPointerDownHandler
{
    public void OnPointerDown(PointerEventData eventData)
    {
        switch (name)
        {
            case "Weapon":
            {
                Player.Default.f_weapon = null;
                break;
            }
            case "Armor":
            {
                Player.Default.f_armor = null;
                break;
            }
        }
    }
}