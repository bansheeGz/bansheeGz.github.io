﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameMenu : MonoBehaviour
{
    public Button load1;
    public Button load2;
    public Button load3;
    public Button save1;
    public Button save2;
    public Button save3;
    public Button back;

    void Start()
    {
        load1.onClick.AddListener(() => Load(1));
        load2.onClick.AddListener(() => Load(2));
        load3.onClick.AddListener(() => Load(3));
        save1.onClick.AddListener(() => Save(1));
        save2.onClick.AddListener(() => Save(2));
        save3.onClick.AddListener(() => Save(3));
        
        UpdateButtons();

        back.onClick.AddListener(() => SceneManager.LoadScene("Main"));
    }

    private void UpdateButtons()
    {
        var files = new SaveLoadFiles();
        load1.interactable = files.Load1Exist;
        load2.interactable = files.Load2Exist;
        load3.interactable = files.Load3Exist;
    }

    private void Load(int index)
    {
        var files = new SaveLoadFiles();
        switch (index)
        {
            case 1:
            {
                files.Load1();
                break;
            }            
            case 2:
            {
                files.Load2();
                break;
            }            
            case 3:
            {
                files.Load3();
                break;
            }            
        }

        UpdateButtons();
    }
    private void Save(int index)
    {
        var files = new SaveLoadFiles();
        switch (index)
        {
            case 1:
            {
                files.Save1();
                break;
            }            
            case 2:
            {
                files.Save2();
                break;
            }            
            case 3:
            {
                files.Save3();
                break;
            }            
        }
        UpdateButtons();
    }
}
