using System;
using BansheeGz.BGDatabase;
using UnityEngine;
using Object = UnityEngine.Object;

//abstract container which has several slots
public class AbstractContainer<T> where T : MonoBehaviour, UiManager.IUpdatableUi
{
    private readonly T[] slots;
    public Action<T[]> OnUpdate;

    public AbstractContainer(int numberOfSlots, RectTransform panel, GameObject slotPrefab, Action<int, T> onCreate = null)
    {
        slots = new T[numberOfSlots];
        for (var i = 0; i < numberOfSlots; i++)
        {
            var slotGo = Object.Instantiate(slotPrefab, panel);
            var slot = slotGo.GetComponent<T>();
            if (onCreate != null) onCreate(i, slot);
            slots[i] = slot;
        }
    }

    public void UpdateUi()
    {
        if (OnUpdate != null) OnUpdate(slots);
        else
            foreach (var slot in slots)
                slot.UpdateUi();
    }

    public void ForEachSlot(Action<T> action)
    {
        foreach (var slot in slots) action(slot);
    }
}