//container for a trader

using System;

//trader container
public class TraderContainer
{
    private const int MaxSize = 10;
    private readonly DbTrader trader;

    public TraderContainer(DbTrader trader)
    {
        if(trader==null)throw new Exception("trader can not be null");
        this.trader = trader;
    }

    public bool TryToAdd(DbItem item)
    {
        if (item == null) throw new Exception("item can not be null");
        
        var stack = item.f_stack;
        return stack < 2 ? AddNonStackable(item) : AddStackable(item, stack);
    }

    private bool AddStackable(DbItem item, int stack)
    {
        var items = trader.f_TraderItems;
        foreach (var anItem in items)
        {
            if(!Equals(anItem.f_item, item)) continue;
            if(anItem.f_amount >= stack) continue;
            anItem.f_amount += 1;
            return true;
        }

        return AddNonStackable(item);
    }

    private bool AddNonStackable(DbItem item)
    {
        var items = trader.f_TraderItems;
        if (items.Count >= MaxSize) return false;

        var newEntity = DbTraderItems.NewEntity(trader);
        newEntity.f_amount = 1;
        newEntity.f_item = item;
        return true;
    }
}