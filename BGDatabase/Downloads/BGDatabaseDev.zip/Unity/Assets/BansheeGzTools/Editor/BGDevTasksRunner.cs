﻿using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEditor;
using UnityEditor.Compilation;
using UnityEngine;

namespace BansheeGz.BGDatabase.Editor.Dev
{
    public static class BGDevTasksRunner
    {
        private static bool AreSourcesUnpacked
        {
            get
            {
                var dir = Directory.GetParent(BGConstants.AssetBGDatabaseSources.Path);
                var directories = Directory.GetDirectories(dir.FullName);
                return directories.Length > 0;
            }
        }

        private static bool IsLocalizationAddonInstalled => BGConstants.AssetBGLocalizationDll.Exists;

        [MenuItem("Tools/Switch to source code")]
        public static void SwitchToSources() => BGDevUtils.Catch(() =>
        {
            BGDevUtils.ThrowIf(AreSourcesUnpacked, "It seems the source files already unpacked");

            Deselect();

            BGConstants.AssetBGDatabaseDll.Disable();
            BGConstants.AssetBGDatabaseEditorDll.Disable();
            BGConstants.AssetBGDatabaseSources.Extract();
            BGConstants.AssetBGDatabaseEditorSources.Extract();

            if (IsLocalizationAddonInstalled)
            {
                BGConstants.AssetBGLocalizationDll.Disable();
                BGConstants.AssetBGLocalizationEditorDll.Disable();
                BGConstants.AssetBGLocalizationSources.Extract();
                BGConstants.AssetBGLocalizationEditorSources.Extract();
            }

            CompilationPipeline.RequestScriptCompilation();

            Ok();
        });

        [MenuItem("Tools/Switch to dll")]
        public static void SwitchToDllUpdateSources() => BGDevUtils.Catch(() =>
        {
            BGDevUtils.ThrowIf(!AreSourcesUnpacked, "It seems the source files are missing");

            Deselect();

            BGConstants.AssetBGDatabaseDll.Enable();
            BGConstants.AssetBGDatabaseEditorDll.Enable();
            BGConstants.AssetBGDatabaseSources.Build(true);
            BGConstants.AssetBGDatabaseEditorSources.Build(true);

            if (IsLocalizationAddonInstalled)
            {
                BGConstants.AssetBGLocalizationDll.Enable();
                BGConstants.AssetBGLocalizationEditorDll.Enable();
                BGConstants.AssetBGLocalizationSources.Build(true);
                BGConstants.AssetBGLocalizationEditorSources.Build(true);
            }

            CompilationPipeline.RequestScriptCompilation();
            
            Ok();
        });

        [MenuItem("Tools/Compile [Windows only]")]
        public static void Compile() => BGDevUtils.Catch(() =>
        {
            BGDevUtils.ThrowIf(!AreSourcesUnpacked, "It seems the source files are missing");

            var buildRoot = SubRoot("Build");
            var isLocalizationAddonInstalled = IsLocalizationAddonInstalled;

            //compile
            var startInfo = new ProcessStartInfo
            {
                WorkingDirectory = buildRoot,
                FileName = isLocalizationAddonInstalled ? "all.bat" : "databaseAll.bat"
            };
            var process = Process.Start(startInfo);
            process.WaitForExit();

            //copy dll files to the project
            File.Copy(Combine(buildRoot, "BGDatabase", "bin", "Release", "BGDatabase.dll"), BGConstants.AssetBGDatabaseDll.Path, true);
            File.Copy(Combine(buildRoot, "BGDatabaseEditor", "bin", "Release", "BGDatabaseEditor.dll"), BGConstants.AssetBGDatabaseEditorDll.Path, true);
            if (isLocalizationAddonInstalled)
            {
                File.Copy(Combine(buildRoot, "BGLocalization", "bin", "Release", "BGLocalization.dll"), BGConstants.AssetBGLocalizationDll.Path, true);
                File.Copy(Combine(buildRoot, "BGLocalizationEditor", "bin", "Release", "BGLocalizationEditor.dll"), BGConstants.AssetBGLocalizationEditorDll.Path, true);
            }

            BGConstants.AssetBGDatabaseDll.Import();
            BGConstants.AssetBGDatabaseEditorDll.Import();
            if (isLocalizationAddonInstalled)
            {
                BGConstants.AssetBGLocalizationDll.Import();
                BGConstants.AssetBGLocalizationEditorDll.Import();
            }
            
            Ok();
        });

        [MenuItem("Tools/Export package(s)")]
        public static void Export() => BGDevUtils.Catch(() =>
        {
            BGDevUtils.ThrowIf(AreSourcesUnpacked, "Please, switch to dll first");

            var packagesRoot = SubRoot("Packages");

            var versions = BGRepo.Version.Split(' ');
            var dbVersion = versions[0];

            //database
            Export(
                Directory.GetParent(BGConstants.AssetBGDatabaseDll.Path).Parent.FullName,
                Path.Combine(packagesRoot, BGUtil.Format("BGDatabase$.unitypackage", dbVersion))
            );

            if (IsLocalizationAddonInstalled)
            {
                //localization
                Export(
                    Directory.GetParent(BGConstants.AssetBGDatabaseDll.Path).Parent.Parent.FullName,
                    Path.Combine(packagesRoot, BGUtil.Format("BGLocalization$.unitypackage", dbVersion))
                );
            }
            
            Ok();
        });

        private static void Export(string basePath, string targetFile)
        {
            var list = new List<string>();
            BGDevUtils.GatherAssets(list, basePath, "*.*", false);
            AssetDatabase.ExportPackage(list.ToArray(), targetFile, ExportPackageOptions.Recurse);
        }

        private static string SubRoot(string folder) => Path.Combine(Directory.GetParent(Path.GetFullPath(Application.dataPath)).Parent.FullName, folder);

        private static void Deselect()
        {
            Selection.activeObject = null;
            Selection.activeGameObject = null;
        }

        private static void Ok() => EditorUtility.DisplayDialog("Information", "Finished OK!", "Ok");

        private static string Combine(string basePath, params string[] subPaths)
        {
            var path = basePath;
            foreach (var subPath in subPaths) path = Path.Combine(path, subPath);
            return path;
        }
    }
}