using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;

namespace BansheeGz.BGDatabase.Editor.Dev
{
    public class BGAssetFile
    {
        private readonly string guid;
        private readonly string name;

        public string Path
        {
            get
            {
                var path = PathNoError;
                if (string.IsNullOrEmpty(path)) throw new Exception($"{name} file is not found");
                return path;
            }
        }

        public string PathNoError => AssetDatabase.GUIDToAssetPath(guid);
        public bool Exists => !string.IsNullOrEmpty(PathNoError);

        public BGAssetFile(string guid, string name)
        {
            this.guid = guid;
            this.name = name;
        }
        public void Import() => AssetDatabase.ImportAsset(Path);
    }

    public class BGDllFile : BGAssetFile
    {
        protected PluginImporter Importer => (PluginImporter)AssetImporter.GetAtPath(Path);

        public BGDllFile(string guid, string name) : base(guid, name)
        {
        }

        public virtual void Enable()
        {
            Importer.SetCompatibleWithAnyPlatform(true);
            Import();
        }

        public virtual void Disable()
        {
            Importer.SetCompatibleWithAnyPlatform(false);
            Import();
        }
    }

    public class BGEditorDllFile : BGDllFile
    {
        public BGEditorDllFile(string guid, string name) : base(guid, name)
        {
        }

        public override void Enable()
        {
            Importer.SetCompatibleWithEditor(true);
            Import();
        }

        public override void Disable()
        {
            Importer.SetCompatibleWithEditor(false);
            Import();
        }
    }

    public class BGSourcesFile : BGAssetFile
    {
        public BGSourcesFile(string guid, string name) : base(guid, name)
        {
        }

        public void Extract() => AssetDatabase.ImportPackage(Path, false);

        public void Build(bool updateSourcesAsset)
        {
            //update sources package
            if (updateSourcesAsset) AssetDatabase.ExportPackage(BGDevUtils.GatherSourceAssetsInSubfolders(Directory.GetParent(Path).FullName, false), Path, ExportPackageOptions.Recurse);

            //delete
            var errors = new List<string>();
            var assets = BGDevUtils.GatherSourceAssetsInSubfolders(Directory.GetParent(Path).FullName, true);
            AssetDatabase.DeleteAssets(assets, errors);
        }
    }
}