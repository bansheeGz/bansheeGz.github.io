using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace BansheeGz.BGDatabase.Editor.Dev
{
    public static class BGDevUtils
    {
        public static void Catch(Action action)
        {
            try
            {
                action();
            }
            catch (Exception e)
            {
                EditorUtility.DisplayDialog("Error", e.Message ?? $"error of type {e.GetType().FullName}", "ok");
                throw;
            }
        }

        public static void ThrowIf(bool condition, string error, params object[] parameters)
        {
            if (!condition) return;
            throw new Exception(string.Format(error, parameters));
        }

        public static string[] GatherSourceAssetsInSubfolders(string dir, bool includeDirs)
        {
            var directories = Directory.GetDirectories(dir);
            var assets = new List<string>();
            foreach (var directory in directories) GatherAssets(assets, directory, "*.cs", includeDirs);

            return assets.ToArray();
        }

        public static void GatherAssets(List<string> assets, string directory, string searchPattern, bool includeDirs)
        {
            var files = Directory.GetFiles(directory, searchPattern, SearchOption.AllDirectories);
            for (var i = 0; i < files.Length; i++) files[i] = GetRelativePath(files[i]);

            string[] dirs = null;
            if (includeDirs)
            {
                dirs = Directory.GetDirectories(directory, "*", SearchOption.AllDirectories);
                Array.Sort(dirs, (p1, p2) => -p1.Length.CompareTo(p2.Length));
                for (var i = 0; i < dirs.Length; i++) dirs[i] = GetRelativePath(dirs[i]);
            }

            assets.AddRange(files);

            if (includeDirs)
            {
                assets.AddRange(dirs);
                assets.Add(GetRelativePath(directory));
            }
        }

        public static string GetRelativePath(string path)
        {
            if (!PathUnderProject(path)) return path;


            var fullPath = Path.GetFullPath(path);
            var dataPathFull = Path.GetFullPath(Application.dataPath);

            var relativePath = fullPath.Substring(dataPathFull.Length);
            if (Path.IsPathRooted(relativePath)) relativePath = relativePath.Substring(1);
            path = Path.Combine("Assets", relativePath);
            return path;
        }
        public static bool PathUnderProject(string path)
        {
            var fullPath = Path.GetFullPath(path);
            var dataPathFull = Path.GetFullPath(Application.dataPath);
            return fullPath.StartsWith(dataPathFull, StringComparison.Ordinal);
        }

    }
}