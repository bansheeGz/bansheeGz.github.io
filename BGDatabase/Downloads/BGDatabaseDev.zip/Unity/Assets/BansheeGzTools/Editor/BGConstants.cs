namespace BansheeGz.BGDatabase.Editor.Dev
{
    public static class BGConstants
    {
        public static BGDllFile AssetBGDatabaseDll = new BGDllFile("f2ce1356528975a42942c7ecfb4189d1", "BGDatabase.dll"); 
        public static BGEditorDllFile AssetBGDatabaseEditorDll = new BGEditorDllFile("fa8f2a05da6c3944f84871cfb8135dde", "BGDatabaseEditor.dll");
        
        public static BGSourcesFile AssetBGDatabaseSources = new BGSourcesFile("9a28cdf1ea586ad4e9f06c6e66a5378a", "BGDatabaseSourceCode.unitypackage");
        public static BGSourcesFile AssetBGDatabaseEditorSources = new BGSourcesFile("372f394895d9a7e4fb3ecd1c5ea72a52", "BGDatabaseEditorSourceCode.unitypackage");

        public static BGDllFile AssetBGLocalizationDll = new BGDllFile("1b7ae5c236262054196c1dee189a8eb0", "BGLocalization.dll"); 
        public static BGEditorDllFile AssetBGLocalizationEditorDll = new BGEditorDllFile("85e7d78f1c4bc674dbadb7290487743e", "BGLocalizationEditor.dll");
        
        public static BGSourcesFile AssetBGLocalizationSources = new BGSourcesFile("b4a99e2766219e54c86efc97e8dea089", "BGLocalizationSourceCode.unitypackage");
        public static BGSourcesFile AssetBGLocalizationEditorSources = new BGSourcesFile("9f429b977b2989845ab239b6241324f9", "BGLocalizationEditorSourceCode.unitypackage");

    }
}