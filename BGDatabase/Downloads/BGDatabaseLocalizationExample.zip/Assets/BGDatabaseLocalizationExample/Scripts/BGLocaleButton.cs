/*
<copyright file="BGLocaleButton.cs" company="BansheeGz">
    Copyright (c) 2018-2020 All Rights Reserved
</copyright>
*/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace BansheeGz.BGDatabase.Example
{
    public partial class BGLocaleButton : BLM_Locale, IPointerDownHandler
    {
        public Image Flag;
        public Text Language;

        public override void EntityChanged()
        {
            Flag.sprite = f_flag;
            Language.text = f_nativeName;
        }

        public void OnPointerDown(PointerEventData eventData)
        {
            Meta.Repo.Addons.Get<BGAddonLocalization>().CurrentLocale = f_name;
        }
    }
}