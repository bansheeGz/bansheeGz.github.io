/*
<copyright file="BGLocalizationMenu.cs" company="BansheeGz">
    Copyright (c) 2018-2020 All Rights Reserved
</copyright>
*/

using System.IO;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace BansheeGz.BGDatabase.Example
{
    public partial class BGLocalizationMenu : MonoBehaviour
    {
        public Image Menu;
        public Image ButtonsHolder;
        public GameObject ButtonPrefab;
        public Text SaveFileLocation;

        public string SaveFilePath
        {
            get { return Path.Combine(Application.persistentDataPath, "bg_save_loc_example.dat"); }
        }

        public bool HasSavedFile
        {
            get { return File.Exists(SaveFilePath); }
        }

        void Start()
        {
            BL_Locale.ForEachEntity(locale =>
            {
                var button = Instantiate(ButtonPrefab, ButtonsHolder.transform);
                button.GetComponent<BLM_Locale>().Entity = locale;
            });

            if (HasSavedFile) SaveFileLocation.text = SaveFilePath;
            Menu.gameObject.SetActive(false);
        }

        // Update is called once per frame
        void Update()
        {
            if (Input.GetKeyDown(KeyCode.Escape)) ToggleMenu();
        }

        public void ToggleMenu()
        {
            var active = !Menu.gameObject.activeSelf;
            Menu.gameObject.SetActive(active);
            var fpsController = FindObjectOfType<BGFirstPersonController>();
            fpsController.MMouseLook.SetCursorLock(!active);
            fpsController.enabled = !active;
        }
        
        public void Save()
        {
            //save
            var bytes = BGRepo.I.Addons.Get<BGAddonSaveLoad>().Save();
            File.WriteAllBytes(SaveFilePath, bytes);
            SaveFileLocation.text = SaveFilePath;
        }

        public void Load()
        {
            //load
            if (!HasSavedFile) return;

            var content = File.ReadAllBytes(SaveFilePath);

            BGRepo.I.Addons.Get<BGAddonSaveLoad>().Load(content);

            //load scene
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }
}