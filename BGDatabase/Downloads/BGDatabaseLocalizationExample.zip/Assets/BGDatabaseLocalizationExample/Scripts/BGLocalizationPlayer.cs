/*
<copyright file="BGLocalizationPlayer.cs" company="BansheeGz">
    Copyright (c) 2018-2020 All Rights Reserved
</copyright>
*/

using UnityEngine;

namespace BansheeGz.BGDatabase.Example
{
    public class BGLocalizationPlayer : MonoBehaviour, BGAddonSaveLoad.BeforeSaveReciever
    {
        // Use this for initialization
        void Awake()
        {
            var player = BL_Player.GetEntity(0);
            transform.position = player.f_position;
            transform.rotation = player.f_rotation;
        }

        //this is called before saving 
        public void OnBeforeSave()
        {
            var player = BL_Player.GetEntity(0);
            player.f_position = transform.position;
            player.f_rotation = transform.rotation;
        }
    }
}