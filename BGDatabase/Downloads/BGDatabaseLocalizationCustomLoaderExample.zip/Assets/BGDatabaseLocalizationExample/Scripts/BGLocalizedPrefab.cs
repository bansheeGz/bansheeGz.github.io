/*
<copyright file="BGLocalizedPrefab.cs" company="BansheeGz">
    Copyright (c) 2018-2020 All Rights Reserved
</copyright>
*/

using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using UnityEngine;

namespace BansheeGz.BGDatabase.Example
{
    public partial class BGLocalizedPrefab : MonoBehaviour
    {
        private GameObject instance;

        public GameObject Prefab
        {
            set
            {
                if (instance != null) Destroy(instance);
                instance = Instantiate(value, transform);
                instance.transform.localPosition = new Vector3(0, 0, -.4f);
                instance.transform.localScale = new Vector3(.2f, .2f, .2f);
            }
        }
    }
}