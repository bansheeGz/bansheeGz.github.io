/*
<copyright file="BGPlaySound.cs" company="BansheeGz">
    Copyright (c) 2018-2020 All Rights Reserved
</copyright>
*/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace BansheeGz.BGDatabase.Example
{
    public partial class BGPlaySound : MonoBehaviour
    {
        private void OnTriggerEnter(Collider other)
        {
            if (other.gameObject.CompareTag("Player"))
            {
                GetComponent<AudioSource>().Play();
            }
        }
    }
}