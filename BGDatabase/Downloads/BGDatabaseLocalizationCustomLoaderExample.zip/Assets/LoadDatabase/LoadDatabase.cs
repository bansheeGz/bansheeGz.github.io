﻿using System.Collections;
using System.Collections.Generic;
using BansheeGz.BGDatabase;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine.SceneManagement;

/// <summary>
/// Load database content from addressables 
/// </summary>
public class LoadDatabase : MonoBehaviour
{
    void Start()
    {
        Addressables.LoadAssetsAsync<TextAsset>("database", null).Completed += OnDatabaseLoaded;
    }

    void OnDatabaseLoaded(AsyncOperationHandle<IList<TextAsset>> handle)
    {
        BGRepoCustomLoaderModel.DatabaseResource database = null;
        var list = handle.Result;
        var assets = new List<TextAssetDatabaseResource>(list.Count);
        foreach (var asset in list)
        {
            var resource = new TextAssetDatabaseResource(asset);
            if (BGRepoCustomLoaderModel.IsDatabaseKey(asset.name)) database = resource;
            else assets.Add(resource);
        }

        if (database != null)
        {
            var model = new BGRepoCustomLoaderModel(database);
            foreach (var resource in assets) model.Add(resource.Asset.name, resource);
            BGRepo.SetDefaultRepoContentModel(model);
        }

        //load game scene
        SceneManager.LoadScene("BGLocalizationScene1");
    }

    private class TextAssetDatabaseResource : BGRepoCustomLoaderModel.DatabaseResource
    {
        private readonly TextAsset asset;

        public TextAsset Asset
        {
            get { return asset; }
        }

        public TextAssetDatabaseResource(TextAsset asset)
        {
            this.asset = asset;
        }

        public override byte[] Content
        {
            get { return asset.bytes; }
        }
    }
}