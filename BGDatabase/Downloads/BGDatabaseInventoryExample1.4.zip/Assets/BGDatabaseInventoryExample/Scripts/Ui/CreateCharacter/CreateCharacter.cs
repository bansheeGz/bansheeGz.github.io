using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class CreateCharacter : MonoBehaviour
{
    public Image characterIcon;
    public InputField nameField;

    //classes
    public RectTransform classesPanel;
    public GameObject classesButtonPrefab;

    //attributes
    public Text attributesText;
    public RectTransform attributesPanel;
    public GameObject attributesPrefab;

    public Button createButton;
    public Button backButton;

    private Button[] classButtons;

    private int attributes = 4;

    private DbPlayerClass PlayerClass
    {
        get
        {
            foreach (var classButton in classButtons)
            {
                if (classButton.interactable) continue;
                return (DbPlayerClass) classButton.GetComponent<DbGoPlayerClass>().Entity;
            }

            return null;
        }
    }

    private void Start()
    {
        nameField.text = "Player";
        classButtons = new Button[DbPlayerClass.CountEntities];
        for (var i = 0; i < DbPlayerClass.CountEntities; i++)
        {
            var index = i;

            var go = Instantiate(classesButtonPrefab, classesPanel);
            classButtons[i] = go.GetComponent<Button>();
            classButtons[i].onClick.AddListener(() => ChoseButton(index));

            go.GetComponentInChildren<Text>().text = DbPlayerClass.GetEntity(i).f_name;
            go.GetComponentInChildren<DbGoPlayerClass>().Entity = DbPlayerClass.GetEntity(i);
        }

        ChoseButton(0);

        backButton.onClick.AddListener(() => SceneManager.LoadScene("Main"));
        createButton.onClick.AddListener(Create);

        UpdateAttributes();

        DbAbility.ForEachEntity(ability =>
        {
            var go = Instantiate(attributesPrefab, attributesPanel);
            var playerAttribute = go.GetComponent<PlayerAttribute>();
            playerAttribute.Controller = new PlayerAttribute.PointsController(
                () => attributes, () =>
                {
                    attributes--;
                    UpdateAttributes();
                }, () =>
                {
                    attributes++;
                    UpdateAttributes();
                });
            playerAttribute.Entity = ability;
        });
    }

    private void UpdateAttributes() => attributesText.text = "" + attributes;

    private void Create()
    {
        Player.Default.Name = nameField.text;
        Player.Default.f_playerClass = PlayerClass;
        SceneManager.LoadScene("Scene1");
    }

    private void ChoseButton(int index)
    {
        for (var i = 0; i < classButtons.Length; i++)
        {
            var classButton = classButtons[i];
            var current = index == i;
            classButton.interactable = !current;
            if (current) characterIcon.sprite = classButton.GetComponent<DbGoPlayerClass>().f_icon;
        }
    }
}