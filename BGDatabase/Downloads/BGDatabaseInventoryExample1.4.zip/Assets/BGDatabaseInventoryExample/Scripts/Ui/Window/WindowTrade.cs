﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//trade with traders here
public class WindowTrade : DbGoTrader, UiManager.IWindow, UiManager.IUpdatableUi
{
    private const int NumberOfInventorySlots = 20;
    private const int NumberOfTraderSlots = 10;

    //============ serializable
    public RectTransform inventoryPanel;
    public GameObject inventorySlotPrefab;

    public RectTransform traderPanel;
    public GameObject traderSlotPrefab;

    public Image traderIcon;
    public Text traderName;
    public Text traderGold;
    public Text playerGold;


    //============ not serializable
    private AbstractContainer<SlotInventoryTrade> inventory;
    private AbstractContainer<SlotTrade> trader;
    private EventsManager eventsManager;

    //================================ Setup UI
    public override void Start()
    {
        //create inventory slots
        inventory = new AbstractContainer<SlotInventoryTrade>(NumberOfInventorySlots, inventoryPanel, inventorySlotPrefab, (i, slot) => slot.Entity = DbInventory.GetEntity(i));

        //create container slots
        trader = new AbstractContainer<SlotTrade>(NumberOfTraderSlots, traderPanel, traderSlotPrefab)
        {
            OnUpdate = slots =>
            {
                List<DbTraderItems> items = null;
                if (Entity != null) items = f_TraderItems;
                for (var i = 0; i < slots.Length; i++)
                {
                    var slot = slots[i];
                    if (items != null && items.Count > i) slot.Entity = items[i];
                    else slot.Entity = null;
                    slot.UpdateUi();
                }
            }
        };


        //register event listener
        eventsManager = new EventsManager(this, new EventsManager.Config
        {
            handler = UpdateUi,
            updated = new[] {DbInventory.MetaDefault.Id, DbTraderItems.MetaDefault.Id, DbTrader.MetaDefault.Id, DbPlayer.MetaDefault.Id},
            added = new[] {DbTraderItems.MetaDefault.Id},
            deleted = new[] {DbTraderItems.MetaDefault.Id},
        });

        //update UI
        UpdateUi();
    }

    public override void OnDestroy() => eventsManager.Dispose();

    private void OnEnable() => UpdateUi();

    public override void EntityChanged() => UpdateUi();

    //================================ Update UI
    public void UpdateUi()
    {
        if (!gameObject.activeSelf || inventory == null) return;
       
        inventory.UpdateUi();
        trader.UpdateUi();

        if (Entity != null)
        {
            inventory.ForEachSlot(slot => slot.Trader = (DbTrader) Entity );
            traderIcon.sprite = f_icon;
            traderName.text = name;
            traderGold.text = "" + f_gold;
        }

        playerGold.text = "" + Player.Default.f_gold;
    }
}