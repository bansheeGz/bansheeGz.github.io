﻿using System.Collections;
using System.Collections.Generic;
using BansheeGz.BGDatabase;
using UnityEngine;

//pickup from a chest
public class WindowChest : DbGoChest, UiManager.IWindow, UiManager.IUpdatableUi
{
    private const int NumberOfInventorySlots = 20;
    private const int NumberOfContainerSlots = 6;

    //============ serializable
    public RectTransform inventoryPanel;
    public GameObject inventorySlotPrefab;

    public RectTransform containerPanel;
    public GameObject containerSlotPrefab;


    //============ not serializable
    private AbstractContainer<SlotInventory> inventory;
    private AbstractContainer<SlotContainer> container;
    private EventsManager eventsManager;

    //================================ Setup UI
    public override void Start()
    {
        //create inventory slots
        inventory = new AbstractContainer<SlotInventory>(NumberOfInventorySlots, inventoryPanel, inventorySlotPrefab, (i, slot) => slot.Entity = DbInventory.GetEntity(i));

        //create container slots
        container = new AbstractContainer<SlotContainer>(NumberOfContainerSlots, containerPanel, containerSlotPrefab)
        {
            OnUpdate = slots =>
            {
                List<DbChestItems> items = null;
                if (Entity != null) items = f_ChestItems;
                for (var i = 0; i < slots.Length; i++)
                {
                    var slot = slots[i];
                    if (items != null && items.Count > i) slot.Entity = items[i];
                    else slot.Entity = null;
                    slot.UpdateUi();
                }
            }
        };


        //register event listener
        eventsManager = new EventsManager(this, new EventsManager.Config
        {
            handler = UpdateUi,
            updated = new[] {DbInventory.MetaDefault.Id, DbChestItems.MetaDefault.Id},
            added = new[] {DbChestItems.MetaDefault.Id},
            deleted = new[] {DbChestItems.MetaDefault.Id},
        });

        //update UI
        UpdateUi();
    }

    public override void OnDestroy() => eventsManager.Dispose();

    private void OnEnable() => UpdateUi();

    public override void EntityChanged() => UpdateUi();

    //================================ Update UI
    public void UpdateUi()
    {
        if (!gameObject.activeSelf || inventory==null) return;
        inventory.UpdateUi();
        container.UpdateUi();
    }
}