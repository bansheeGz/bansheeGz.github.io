BGDatabase runtime editor by BancheeGz, (c) 2018-2020 
Home page: https://www.bansheegz.com/BGDatabase/Downloads/RuntimeEditor/
