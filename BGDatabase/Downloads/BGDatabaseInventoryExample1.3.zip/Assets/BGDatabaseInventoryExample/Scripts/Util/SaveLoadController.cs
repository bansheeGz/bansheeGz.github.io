using System.Collections.Generic;
using BansheeGz.BGDatabase;

//this is SaveLoad row level controller implementation without using CodeGen classes
public class SaveLoadController  : BGMergeSettingsEntity.IMergeReceiver, BGMergeSettingsEntity.IUpdateMatchingReceiver, BGMergeSettingsEntity.IRemoveOrphanedReceiver
{
    //this field is used to detect if it's loading or saving
    private bool loading;
    //this is a set of chest IDs with version > saved version
    private readonly HashSet<BGId> newChestsId = new HashSet<BGId>();
    //this is a set of trader IDs with version > saved version
    private readonly HashSet<BGId> newTradersId = new HashSet<BGId>();
    //this is a "ChestItems.Chest" field, which can be used to retrieve the related Chest row for ChestItems row
    private BGFieldRelationSingle chestRelation;
    //this is a "TraderItems.Trader" field, which can be used to retrieve the related Trader row for TraderItems row
    private BGFieldRelationSingle traderRelation;

    //this method is called before repos data merging
    public bool OnBeforeMerge(BGRepo from, BGRepo to)
    {
        //here we want to know, if it's loading or saving? If target repo is default repo- it means loading
        loading = to == BGRepo.I;
        
        if (loading)
        {
            //let's find out the saved version
            var savedVersion = 0;
            var savedVersionMeta = from.GetMeta("Version");
            var savedVersionField = (BGFieldInt)savedVersionMeta?.GetField("version", false);
            if (savedVersionField != null) savedVersion = savedVersionField[0];

            //now let's iterate the chests and find the chests with version > savedVersion and add their IDs to newChestsId hashset
            Fill(to, "Chest", newChestsId, savedVersion);
            //now let's iterate the traders and find the traders with version > savedVersion and add their IDs to newTradersId hashset
            Fill(to, "Trader", newTradersId, savedVersion);
            
            //retrieve "ChestItems.Chest" field from default repo (we will use it later)
            chestRelation = (BGFieldRelationSingle) to.GetMeta("ChestItems").GetField("Chest");
            //retrieve "TraderItems.Trader" field from default repo (we will use it later)
            traderRelation = (BGFieldRelationSingle) to.GetMeta("TraderItems").GetField("Trader");
        }
        return false;
    }

    public void OnAfterMerge(BGRepo from, BGRepo to)
    {
    }

    //this method is called before row removal, if it returns true, it means the removal is cancelled
    public bool OnBeforeDelete(BGEntity toEntity)
    {
        if (loading)
        {
            switch (toEntity.MetaName)
            {
                case "ChestItems": return Check(chestRelation, toEntity.Index, newChestsId);
                case "TraderItems": return Check(traderRelation, toEntity.Index, newTradersId);
            }
        }
        return false;
    }

    //this method is called before matching row update
    public bool OnBeforeUpdate(BGEntity from, BGEntity to)
    {
        if (loading)
        {
            //we want to use the latest version from default database, skip update
            if (from.MetaName == "Version") return true;
        }
        return false;
    }
    
    private static void Fill(BGRepo to, string metaName, HashSet<BGId> hashSet, int savedVersion)
    {
        var meta = to.GetMeta(metaName);
        var versionField = (BGFieldInt)meta.GetField("version");
        meta.ForEachEntity(entity => hashSet.Add(entity.Id), entity => versionField[entity.Index] > savedVersion);
    }
    private static bool Check(BGFieldRelationSingle relation, int entityIndex, HashSet<BGId> hashSet)
    {
        //get related owner ID
        var parentId = relation[entityIndex].Id;
        //if parent row is new, skip child row removal
        if (hashSet.Contains(parentId)) return true;
        return false;
    }
}
