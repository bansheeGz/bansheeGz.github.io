using System.IO;
using BansheeGz.BGDatabase;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SaveLoadFiles
{
    private const string LoadFile1 = "bgdatabase_save1.dat";
    private const string LoadFile2 = "bgdatabase_save2.dat";
    private const string LoadFile3 = "bgdatabase_save3.dat";

    public bool Load1Exist
    {
        get { return Exists(LoadFile1); }
    }

    public bool Load2Exist
    {
        get { return Exists(LoadFile2); }
    }

    public bool Load3Exist
    {
        get { return Exists(LoadFile3); }
    }

    private static bool Exists(string file)
    {
        return File.Exists(GetPath(file));
    }

    private static string GetPath(string file)
    {
        return Path.Combine(Application.persistentDataPath, file);
    }

    public void Load1()
    {
        Load(LoadFile1);
    }

    public void Load2()
    {
        Load(LoadFile2);
    }

    public void Load3()
    {
        Load(LoadFile3);
    }

    public void Save1()
    {
        Save(LoadFile1);
    }

    public void Save2()
    {
        Save(LoadFile2);
    }

    public void Save3()
    {
        Save(LoadFile3);
    }

    private void Save(string file)
    {
        File.WriteAllBytes(GetPath(file), BGRepo.I.Addons.Get<BGAddonSaveLoad>().Save());
    }

    private void Load(string file)
    {
        BGRepo.I.Addons.Get<BGAddonSaveLoad>().Load(File.ReadAllBytes(GetPath(file)));
        SceneManager.LoadScene(Player.Default.f_scene, LoadSceneMode.Single);
    }
}