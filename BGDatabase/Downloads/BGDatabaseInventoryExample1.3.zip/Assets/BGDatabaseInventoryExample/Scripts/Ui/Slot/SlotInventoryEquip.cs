using UnityEngine.EventSystems;

//slot for inventory while picking items from a chest
public class SlotInventoryEquip : SlotInventory, IPointerDownHandler
{
    
     public void OnPointerDown(PointerEventData eventData)
     {
         if (f_item == null) return;
         switch (f_item)
         {
             case DbWeapon weapon:
             {
                 Player.Default.f_weapon = (DbInventory) Entity;
                 break;
             }
             case DbArmor armor:
             {
                 Player.Default.f_armor = (DbInventory) Entity;
                 break;
             }
             
         }
     }
 }