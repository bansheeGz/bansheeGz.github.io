﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//popup messages (like Press e to open)
public class WindowPopup : MonoBehaviour, UiManager.IWindow
{
    public Text PopupText;

    public IEnumerator removePopupCoroutine;
    private IPopupProvider provider;


    public IPopupProvider Popup
    {
        set
        {
            if (UiManager.FormIsOpened || ReferenceEquals(provider, value)) return;

            provider = value;
            if (removePopupCoroutine != null) StopCoroutine(removePopupCoroutine);
            removePopupCoroutine = null;


            var popupIsActive = provider != null;
            gameObject.SetActive(popupIsActive);

            if (!popupIsActive) PopupText.text = null;
            else
            {
                PopupText.text = provider.Text;
                removePopupCoroutine = RemovePopup();
                StartCoroutine(removePopupCoroutine);
            }
        }
    }

    void Start()
    {
        Popup = null;
    }


    private IEnumerator RemovePopup()
    {
        while (provider != null && provider.IsActive) yield return null;
        Popup = null;
    }


    public interface IPopupProvider
    {
        string Text { get; }
        bool IsActive { get; }
    }
}