using System;
using System.Collections.Generic;
using UnityEngine;

//container for inventory
public class InventoryContainer
{
    //this is a reusable list to get rid of GC
    private static readonly List<DbInventory> List = new List<DbInventory>();

    //try to add item to inventory. Return the number of items which was not added (inventory is full)
    public int TryToAdd(DbInventory_Relation_f_item item, int amount)
    {
        if (item == null) throw new Exception("item can not be null");
        if (amount == 0) throw new Exception("Amount should be > 0");

        List.Clear();
        
        var stack = item.f_stack;
        return stack < 2 ? AddNotStackable(item, amount) : AddStackable(item, amount, stack);
    }

    //add stackable item 
    private static int AddStackable(DbInventory_Relation_f_item item, int toAdd, int stack)
    {
        DbInventory.ForEachEntity(inventory => List.Add(inventory));

        //first, lets try to assign it to existing stacks
        for (var i = 0; i < List.Count && toAdd > 0; i++)
        {
            var inventorySlot = List[i];
            if (!Equals(inventorySlot.f_item, item) || inventorySlot.f_amount >= stack) continue;
            toAdd = Transfer(inventorySlot, toAdd, stack);
        }

        //all transferred
        if (toAdd <= 0) return 0;

        //now we try to use empty slots
        for (var i = 0; i < List.Count && toAdd > 0; i++)
        {
            var inventorySlot = List[i];
            if (inventorySlot.f_item != null) continue;
            inventorySlot.f_amount = 0;
            inventorySlot.f_item = item;
            toAdd = Transfer(inventorySlot, toAdd, stack);
        }

        return toAdd;
    }

    //add not stackable item  
    private static int AddNotStackable(DbInventory_Relation_f_item item, int toAdd)
    {
        
        var slots = DbInventory.FindEntities(inventory => inventory.f_item == null, List);
        for (var i = 0; i < slots.Count && toAdd > 0; i++)
        {
            var slot = slots[i];
            slot.f_item = item;
            slot.f_amount = 1;
            toAdd--;
        }

        return toAdd;
    }

    //transfer items to inventory
    private static int Transfer(DbInventory to, int toAdd, int stack)
    {
        var canBeTransferred = stack - to.f_amount;
        if (canBeTransferred >= toAdd)
        {
            to.f_amount += toAdd;
            return 0;
        }

        to.f_amount += canBeTransferred;
        return toAdd - canBeTransferred;
    }
}