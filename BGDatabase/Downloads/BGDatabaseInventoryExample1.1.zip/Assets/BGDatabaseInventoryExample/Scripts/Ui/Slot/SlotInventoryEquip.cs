using UnityEngine.EventSystems;

//slot for inventory while picking items from a chest
public class SlotInventoryEquip : SlotInventory, IPointerDownHandler
{
    private DbInventory_Relation_f_item Item => (DbInventory_Relation_f_item)f_item;
     
     public void OnPointerDown(PointerEventData eventData)
     {
         if (Item == null) return;
         switch (Item)
         {
             case DbWeapon weapon:
             {
                 Player.Default.f_weapon = (DbInventory) Entity;
                 break;
             }
             case DbArmor armor:
             {
                 Player.Default.f_armor = (DbInventory) Entity;
                 break;
             }
             
         }
 
         /*
         switch (f_item.f_type.Index)
         {
             case 0:
             {
                 //weapon
                 Player.Default.f_weapon = (DbInventory) Entity;
                 break;
             }
             case 1:
             {
                 //armor
                 Player.Default.f_armor = (DbInventory) Entity;
                 break;
             }
                 
         }
     */
     }
     
     
 }