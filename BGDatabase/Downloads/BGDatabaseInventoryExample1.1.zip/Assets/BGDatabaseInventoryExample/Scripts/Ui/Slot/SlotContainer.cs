using System.Collections.Generic;
using BansheeGz.BGDatabase;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

//pickup container slot
public class SlotContainer : DbGoChestItems, IPointerDownHandler, UiManager.IUpdatableUi
{
    //serializable
    public Image itemIcon;
    public Image amountIcon;
    public Text amountText;

    //non serializable
    private SlotAbstract abstractSlot;

    public override void EntityChanged()
    {
        UpdateUi();
    }

    public void UpdateUi()
    {
        Utils.Assign(ref abstractSlot, () => new SlotAbstract(itemIcon, amountIcon, amountText));
        if (Entity == null) abstractSlot.UpdateUi(null, 0);
        else abstractSlot.UpdateUi(((DbChestItems_Relation_f_item)f_item).f_icon, f_amount);
    }


    // On Mouse Click
    public void OnPointerDown(PointerEventData eventData)
    {
        if (Entity == null || f_item == null) return;

        var chestItem = (DbChestItems)Entity;

        var leftAmount = new InventoryContainer().TryToAdd((DbInventory_Relation_f_item)f_item, chestItem.f_amount == 0 ? 1 : chestItem.f_amount);

        if (leftAmount == 0) chestItem.Delete();
        else
        {
            chestItem.f_amount = leftAmount;
            UiManager.ShowAlert("Inventory is full");
        }
    }
}