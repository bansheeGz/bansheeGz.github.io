﻿using System;
using System.Collections;
using System.Collections.Generic;
using BansheeGz.BGDatabase;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MainMenu : MonoBehaviour
{
    public Button NewGameButton;
    public Button Load1Button;
    public Button Load2Button;
    public Button Load3Button;
    public Button QuitButton;
    
    void Start()
    {
        BGRepo.Load();
        
        NewGameButton.onClick.AddListener(() => SceneManager.LoadScene("NewGame"));
        QuitButton.onClick.AddListener(Application.Quit);
        
        var files = new SaveLoadFiles();
        ProcessButton(Load1Button, files.Load1Exist, () => files.Load1());
        ProcessButton(Load2Button, files.Load2Exist, () => files.Load2());
        ProcessButton(Load3Button, files.Load3Exist, () => files.Load3());
    }

    private static void ProcessButton(Button button, bool enabled, UnityAction action)
    {
        if (enabled) button.onClick.AddListener(action);
        else button.interactable = false;
        
    }
}
