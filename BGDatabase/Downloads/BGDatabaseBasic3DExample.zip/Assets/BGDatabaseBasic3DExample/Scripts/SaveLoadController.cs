using System.Collections.Generic;
using BansheeGz.BGDatabase;

//this is SaveLoad row level controller implementation without using CodeGen classes
public class SaveLoadController  : BGMergeSettingsEntity.IMergeReceiver, BGMergeSettingsEntity.IUpdateMatchingReceiver, BGMergeSettingsEntity.IRemoveOrphanedReceiver
{
    //this field is used to detect if it's loading or saving
    private bool loading;
    //this is a set of scene IDs with version > saved version
    private readonly HashSet<BGId> newScenesId = new HashSet<BGId>();
    //this is a "Collectable.Scene" field, which can be used to retrieve the related Scene row for Collectable row
    private BGFieldRelationSingle sceneRelation;

    //this method is called before repos data merging
    public bool OnBeforeMerge(BGRepo from, BGRepo to)
    {
        //here we want to know, if it's loading or saving? If target repo is default repo- it means loading
        loading = to == BGRepo.I;
        
        if (loading)
        {
            //let's find out the saved version
            var savedVersion = 0;
            var savedVersionMeta = from.GetMeta("Version");
            var savedVersionField = (BGFieldInt)savedVersionMeta?.GetField("version", false);
            if (savedVersionField != null) savedVersion = savedVersionField[0];

            //now let's iterate the scenes and find the scenes with version > savedVersion and add their IDs to newScenesId hashset 
            var sceneMeta = to.GetMeta("Scene");
            var versionField = (BGFieldInt)sceneMeta.GetField("version");
            sceneMeta.ForEachEntity(entity => newScenesId.Add(entity.Id), entity => versionField[entity.Index] > savedVersion);
            
            //retrieve "Collectable.Scene" field from default repo (we will use it later)
            sceneRelation = (BGFieldRelationSingle) to.GetMeta("Collectable").GetField("Scene");
        }
        return false;
    }

    public void OnAfterMerge(BGRepo from, BGRepo to)
    {
    }

    //this method is called before row removal, if it returns true, it means the removal is cancelled
    public bool OnBeforeDelete(BGEntity toEntity)
    {
        if (loading)
        {
            //if it's Collectable row
            if (toEntity.MetaName == "Collectable")
            {
                //get related scene ID
                var sceneId = sceneRelation[toEntity.Index].Id;
                //if scene is new, skip Collectable row removal
                if (newScenesId.Contains(sceneId)) return true;
            }
        }
        return false;
    }

    //this method is called before matching row update
    public bool OnBeforeUpdate(BGEntity from, BGEntity to)
    {
        if (loading)
        {
            //we want to use the latest version from default database, skip update
            if (from.MetaName == "Version") return true;
        }
        return false;
    }
}
