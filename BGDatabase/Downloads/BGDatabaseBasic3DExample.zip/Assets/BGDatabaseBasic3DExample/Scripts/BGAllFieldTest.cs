/*
<copyright file="BGAllFieldTest.cs" company="BansheeGz">
    Copyright (c) 2018-2020 All Rights Reserved
</copyright>
*/

using UnityEngine;

namespace BansheeGz.BGDatabase.Example
{
    public partial class BGAllFieldTest : MonoBehaviour
    {
        private BGEntityGo entity;

        void Start()
        {
            entity = GetComponent<BGEntityGo>();

            Rebuild();
            var events = BGRepo.I.Events;
            events.On = true;
            events.AddEntityUpdatedListener(entity.EntityId, EntityChanged);
        }

        void OnDestroy()
        {
            BGRepo.I.Events.RemoveEntityUpdatedListener(entity.EntityId, EntityChanged);
        }

        private void EntityChanged(object sender, BGEventArgsEntityUpdated e)
        {
            Rebuild();
        }

        private void Rebuild()
        {
            if (entity.Entity == null) return;
            var value = "                   ALL FIELDS VALUES\n\n";
            entity.Meta.ForEachField(field =>
            {
                string fieldValue;
                if (field is BGFieldCalcI) fieldValue = field.GetValue(entity.Entity.Index)?.ToString() ?? "null";
                else fieldValue = field.ToString(entity.Entity.Index);

                value += field.Name + "=" + fieldValue + '\n';
            });
            GetComponent<TextMesh>().text = value;
        }
    }
}