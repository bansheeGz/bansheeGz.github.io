using System;
using UnityEngine;

public class SaveLoadUI : MonoBehaviour
{
    private void OnGUI()
    {
        ShowButton("Save default", SaveLoadManager.SaveDefault);
        ShowButton("Save settings", SaveLoadManager.SaveSettings);
        ShowButton("Load default only with preserve request (only default config will be loaded)", SaveLoadManager.LoadDefaultWithPreserveRequest);
        ShowButton("Load settings only (only settings config will be loaded)", SaveLoadManager.LoadSettingsWithoutDatabaseReload);
        ShowButton("Load both from files (both configs will be loaded)", SaveLoadManager.LoadAllUsingFileContent);
    }

    private static void ShowButton(string message, Action action)
    {
        if (!GUILayout.Button(message)) return;
        action();
    }
}
