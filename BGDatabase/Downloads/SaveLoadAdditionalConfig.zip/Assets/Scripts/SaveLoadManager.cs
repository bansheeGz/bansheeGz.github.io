using System;
using System.Collections.Generic;
using System.IO;
using BansheeGz.BGDatabase;
using UnityEngine;

public static class SaveLoadManager
{
    private const string SettingsConfigName = "Settings";
    private static string DefaultSaveFile => Path.Combine(Application.persistentDataPath, "save.dat");
    private static string SettingsSaveFile => Path.Combine(Application.persistentDataPath, "settings.dat");

    //------------------------- Save section
    public static void SaveAll()
    {
        SaveDefault();
        SaveSettings();
    }

    public static void SaveDefault() => Save(DefaultSaveFile, BGRepo.I.Addons.Get<BGAddonSaveLoad>().Save());
    public static void SaveSettings() => Save(SettingsSaveFile, BGRepo.I.Addons.Get<BGAddonSaveLoad>().Save(new BGSaveLoadAddonSaveContext(SettingsConfigName)));

    private static void Save(string path, byte[] content)
    {
        File.WriteAllBytes(path, content);
        Debug.Log($"Saved to {path} file");
    }

    //------------------------- Load section
    public static void LoadDefaultWithPreserveRequest()
    {
        Load(DefaultSaveFile, content =>
        {
            BGRepo.I.Addons.Get<BGAddonSaveLoad>().Load(
                new BGSaveLoadAddonLoadContext(new BGSaveLoadAddonLoadContext.LoadRequest(BGAddonSaveLoad.DefaultSettingsName, content))
                {
                    //the data for "Settings" config will be saved before database is reloaded and loaded after database is reloaded
                    PreserveRequests = new List<BGSaveLoadAddonLoadContext.PreserveRequest> { new BGSaveLoadAddonLoadContext.PreserveRequest(SettingsConfigName) }
                }
            );
        });
    }

    public static void LoadAllUsingFileContent()
    {
        //main (Default) configuration 
        Load(DefaultSaveFile, content => BGRepo.I.Addons.Get<BGAddonSaveLoad>().Load(content));

        //additional (settings) configuration
        LoadSettingsWithoutDatabaseReload();
    }
    
    public static void LoadSettingsWithoutDatabaseReload()
    {
        Load(SettingsSaveFile, content =>
        {
            BGRepo.I.Addons.Get<BGAddonSaveLoad>().Load(
                new BGSaveLoadAddonLoadContext(
                    new BGSaveLoadAddonLoadContext.LoadRequest(SettingsConfigName, content)
                )
                {
                    //prevent database reloading
                    ReloadDatabase = false
                }
            );
        });
    }
    
    private static void Load(string path, Action<byte[]> action)
    {
        if (File.Exists(path)) action(File.ReadAllBytes(path));
        else Debug.Log($"File {path} can not be found");
    }
}