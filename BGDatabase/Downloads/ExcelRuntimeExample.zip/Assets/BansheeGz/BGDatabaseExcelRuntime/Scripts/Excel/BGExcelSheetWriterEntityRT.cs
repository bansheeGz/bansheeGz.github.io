/*
<copyright file="BGExcelSheetWriterEntityRT.cs" company="BansheeGz">
    Copyright (c) 2019 All Rights Reserved
</copyright>
*/

using NPOI.SS.UserModel;

namespace BansheeGz.BGDatabase
{
    public class BGExcelSheetWriterEntityRT : BGExcelSheetWriterART
    {
        private readonly BGMergeSettingsEntity settings;

        public BGExcelSheetWriterEntityRT(BGLogger logger, BGRepo repo, IWorkbook book, BGBookInfo bookInfo, BGMergeSettingsEntity settings) : base(logger, repo, book, bookInfo)
        {
            this.settings = settings;
        }


        public void Write()
        {
            repo.ForEachMeta(meta =>
            {
                //CHANGED: if no settings
                if (settings != null && !settings.IsAddingMissing(meta.Id) && !settings.IsUpdatingMatching(meta.Id) && !settings.IsRemovingOrphaned(meta.Id)) return;
                
                logger.SubSection(() =>
                {
                    Sheet(meta.Name,
                        settings == null || settings.Mode == BGMergeModeEnum.Transfer,
                        () => bookInfo.GetEntitySheet(meta.Id),
                        () =>
                        {
                            var info = new BGEntitySheetInfo(meta.Id, meta.Name, book.NumberOfSheets - 1);
                            bookInfo.AddEntitySheet(meta.Id, info);
                            return info;
                        },
                        info =>
                        {
                            logger.SubSection(() =>
                            {
                                //headers
                                Row(0, () =>
                                {
                                    info.IndexId = MapHeader(BGBookInfo.IdHeader, info.IndexId);

                                    meta.ForEachField(field =>
                                    {
                                        if (info.HasField(field.Id))
                                        {
                                            logger.AppendLine("Field $ column found at index $", field.Name, info.GetFieldColumn(field.Id));
                                            return;
                                        }

                                        info.AddField(field.Id, NewCellIndex);
                                        Cell(info.GetFieldColumn(field.Id), field.Name);

                                        logger.AppendLine("Field $ column not found. Created new column at index $", field.Name, info.GetFieldColumn(field.Id));
                                    });
                                });
                            }, "Mapping for ($) entities.", meta.Name);

                            //Values
                            var isAdding = settings==null || settings.IsAddingMissing(meta.Id);
                            var isUpdating = settings==null || settings.IsUpdatingMatching(meta.Id);
                            meta.ForEachEntity(entity =>
                            {
                                int rowIndex;
                                if (!GetRowIndex(info, entity.Id, isAdding, isUpdating, out rowIndex)) return;

                                Row(rowIndex, () =>
                                {
                                    Cell(info.IndexId, entity.Id.ToString());
                                    meta.ForEachField(field =>
                                    {
                                        var value = BGUtil.ToString(field, entity.Index);
                                        Cell(info.GetFieldColumn(field.Id), value);
                                    });
                                });
                            });

                            if (settings==null || settings.IsRemovingOrphaned(meta.Id)) Remove(info, id => !meta.HasEntity(id));
                            
                            logger.AppendLine("$ entities are processed.", meta.CountEntities);
                        });
                }, "Writing entities for $ meta", meta.Name);
            });
        }
    }
}