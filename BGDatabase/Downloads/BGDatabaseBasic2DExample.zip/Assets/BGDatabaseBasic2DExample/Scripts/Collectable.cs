﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Collectable : M_Collectable
{
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            var player = other.GetComponent<Player>();
            player.f_gold += f_gold;
            
            var audioSource = player.GetComponent<AudioSource>();
            audioSource.clip = f_type.f_audio;
            audioSource.Play();

            Instantiate(player.GatherEffect, transform.position, Quaternion.identity);
            
            Entity.Delete();
            Destroy(gameObject);
        }
    }

    public override void EntityChanged() => GetComponentInChildren<TextMesh>().text = "Gold: " + f_gold;

}