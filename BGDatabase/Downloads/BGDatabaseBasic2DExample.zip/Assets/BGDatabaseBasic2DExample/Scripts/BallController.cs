﻿using UnityEngine;

public class BallController : MonoBehaviour
{
    private const float speed = 8;
    private const float rotationSpeed = 600;

    void Update()
    {
        if (Input.GetKey(KeyCode.A))
        {
            Move(true);
        }
        else if (Input.GetKey(KeyCode.D))
        {
            Move(false);
        }
    }

    private void Move(bool left)
    {
        //position
        var distance = Time.deltaTime * speed;
        if (left) distance = -distance;
        transform.position += new Vector3(distance, 0, 0);

        //rotation
        var angle = Time.deltaTime * rotationSpeed;
        if (!left) angle = -angle;
        transform.RotateAround(transform.position, Vector3.forward, angle);
    }

    private void OnGUI()
    {
        if(GUI.RepeatButton(new Rect(200,0,200,100), "Left")) Move(true);
        if(GUI.RepeatButton(new Rect(400,0,200,100), "Right")) Move(false);
    }
}