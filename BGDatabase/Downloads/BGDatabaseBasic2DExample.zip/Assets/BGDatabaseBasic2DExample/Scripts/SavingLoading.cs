﻿using System.IO;
using BansheeGz.BGDatabase;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SavingLoading : MonoBehaviour
{
    public bool HasSavedFile
    {
        get { return File.Exists(SaveFilePath); }
    }

    public string SaveFilePath
    {
        get { return Path.Combine(Application.persistentDataPath, "bg_save_example2d.dat"); }
    }

    public void Save()
    {
        File.WriteAllBytes(SaveFilePath, BGRepo.I.Addons.Get<BGAddonSaveLoad>().Save());
    }

    public void Load()
    {
        if (!HasSavedFile) return;

        BGRepo.I.Addons.Get<BGAddonSaveLoad>().Load(File.ReadAllBytes(SaveFilePath));
        SceneManager.LoadScene(E_Player.GetEntity(0).f_scene.Name);
    }
}