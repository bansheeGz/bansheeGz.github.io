﻿using System.Collections;
using System.Collections.Generic;
using BansheeGz.BGDatabase;
using UnityEngine;

public class Spawner : M_Scene
{
    public override void Start()
    {
        base.Start();
        Spawn();
        //listen to entity deleted event on collectable table
        Events.AddAnyEntityDeletedListener(E_Collectable.MetaDefault.Id, EntityDeleted);
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        Events.RemoveAnyEntityDeletedListener(E_Collectable.MetaDefault.Id, EntityDeleted);
    }

    private void EntityDeleted(object sender, BGEventArgsAnyEntity e)
    {
        if (E_Collectable.MetaDefault.CountEntities > 0) return;
        E_Scene.ForEachEntity(scene =>
        {
            //number of objects to be spawned
            var count = Random.Range(3, 6);
            for (var i = 0; i < count; i++)
            {
                //create table row
                var newCollectable = E_Collectable.NewEntity(scene);
                //assign some gold to it
                newCollectable.f_gold = Random.Range(1, 10);
                //get scene area
                var bounds = scene.f_bounds;
                //assign position within that area
                newCollectable.f_position = new Vector2(Random.Range(bounds.min.x, bounds.max.x), Random.Range(bounds.min.y, bounds.max.y));
                //assign random type    
                newCollectable.f_type = E_CollectableType.GetEntity(Random.Range(0, E_CollectableType.CountEntities));
            }
        });
        Spawn();
    }

    private void Spawn()
    {
        var collectables = f_Collectable;
        if (collectables == null || collectables.Count == 0) return;
        foreach (var collectable in collectables)
        {
            var newCollectable = Instantiate(collectable.f_type.f_prefab, collectable.f_position, Quaternion.identity);
            newCollectable.GetComponent<Collectable>().Entity = collectable;
        }
    }
}