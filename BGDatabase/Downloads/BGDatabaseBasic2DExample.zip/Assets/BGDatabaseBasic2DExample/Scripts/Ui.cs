﻿using BansheeGz.BGDatabase;
using UnityEngine;
using UnityEngine.UI;

public class Ui : M_Player
{
    public Text GoldText;

    public override void Start()
    {
        UpdateGold();
        Events.AddEntityUpdatedListener(Entity.Id, EntityUpdated);
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        Events.RemoveEntityUpdatedListener(Entity.Id, EntityUpdated);
    }

    private void EntityUpdated(object sender, BGEventArgsEntityUpdated e)
    {
        if (e.FieldId != _f_gold.Id) return;
        UpdateGold();
    }

    private void UpdateGold()
    {
        GoldText.text = "Gold: " + f_gold;
    }


    private bool active;
    public Image SaveLoadMenu;

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape)) Menu();
    }

    private void Menu()
    {
        active = !active;
        SaveLoadMenu.gameObject.SetActive(active);
    }

    private void OnGUI()
    {
        if (GUI.Button(new Rect(600, 0, 200, 100), "Menu")) Menu();
    }
}