﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class Portal : M_Scene
{
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            other.GetComponent<M_Player>().f_position = f_spawnPosition;
            SceneManager.LoadScene(f_name);
        }
    }
}