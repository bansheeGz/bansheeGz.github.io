﻿using BansheeGz.BGDatabase;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Player : M_Player, BGAddonSaveLoad.BeforeSaveReciever
{
	public GameObject GatherEffect;
	void Start ()
	{
		transform.position = f_position;
	}

	public void OnBeforeSave()
	{
		// if prefab- no action
		if (gameObject.scene.name == null) return;
		f_position = transform.position;
		var activeScene = SceneManager.GetActiveScene().name;
		f_scene = E_Scene.FindEntity(scene => string.Equals(scene.Name, activeScene));
	}
}
