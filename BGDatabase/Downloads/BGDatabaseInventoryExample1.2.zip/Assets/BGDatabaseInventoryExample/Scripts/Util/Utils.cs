    using System;

    //just some utils
    public static class Utils
    {
        public static void Assign<T>(ref T target, Func<T> provider) where T:class
        {
            if (target != null) return;
            target = provider();
        }
    }
