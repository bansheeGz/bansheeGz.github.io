﻿using System;
using UnityEngine;

//some object which interacts with the player
public class Interactable : WindowPopup.IPopupProvider
{
    private const int MaxAngle = 30;
    
    private readonly Transform transform;
    private readonly Action interact;
    private readonly string popupText;
    private readonly Vector3 centerOffset;

    private bool nearPlayer;
    
    public Interactable(Transform transform, Vector3 centerOffset, string popupText, Action interact) 
    {
        this.transform = transform;
        this.centerOffset = centerOffset;
        this.popupText = popupText;
        this.interact = interact;
    }

    public void OnTriggerStay(Collider other)
    {
        if (!Player.IsPlayer(other.gameObject)) return;
        nearPlayer = true;
        if (!IsActive) return;

        UiManager.Get<WindowPopup>().Popup = this;
        if (Input.GetKeyDown(KeyCode.E)) interact();
    }

    public void OnTriggerExit(Collider other)
    {
        if (Player.IsPlayer(other.gameObject)) nearPlayer = false;
    }

    //======================== Popup UI
    public string Text
    {
        get { return popupText; }
    }

    public bool IsActive
    {
        get
        {
            if (!nearPlayer) return false;
            var cam = Player.Instance.Camera;
            var playerForward = Quaternion.LookRotation(cam.transform.forward);
            var player2Me = Quaternion.LookRotation(transform.position + centerOffset - cam.transform.position);
            var angle = Quaternion.Angle(playerForward, player2Me);
            return angle < MaxAngle;
        }
    }
}