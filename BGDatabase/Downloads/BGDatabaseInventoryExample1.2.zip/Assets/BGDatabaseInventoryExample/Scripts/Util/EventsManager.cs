using System;
using System.Collections;
using System.Collections.Generic;
using BansheeGz.BGDatabase;
using UnityEngine;

//This class handles events
public class EventsManager : IDisposable
{
    private readonly Config config;
    private readonly MonoBehaviour owner;
    private bool updating;

    public EventsManager(MonoBehaviour owner, Config config)
    {
        this.owner = owner;
        this.config = config;

        //attach listeners
        if (config.added != null)
            foreach (var metaId in config.added)
                BGRepo.I.Events.AddAnyEntityAddedListener(metaId, Handler);
        if (config.updated != null)
            foreach (var metaId in config.updated)
                BGRepo.I.Events.AddAnyEntityUpdatedListener(metaId, Handler);
        if (config.deleted != null)
            foreach (var metaId in config.deleted)
                BGRepo.I.Events.AddAnyEntityDeletedListener(metaId, Handler);
    }

    public void Dispose()
    {
        //remove listeners
        if (config.added != null)
            foreach (var metaId in config.added)
                BGRepo.I.Events.RemoveAnyEntityAddedListener(metaId, Handler);
        if (config.updated != null)
            foreach (var metaId in config.updated)
                BGRepo.I.Events.RemoveAnyEntityUpdatedListener(metaId, Handler);
        if (config.deleted != null)
            foreach (var metaId in config.deleted)
                BGRepo.I.Events.RemoveAnyEntityDeletedListener(metaId, Handler);
    }

    private void Handler(object sender, BGEventArgsAnyEntity e)
    {
        if (updating || owner == null || !owner.isActiveAndEnabled) return;

        updating = true;
        //we do not call config.handler() directly here, cause we want to call it only once per frame
        owner.StartCoroutine(DoUpdate());
    }

    private IEnumerator DoUpdate()
    {
        yield return new WaitForEndOfFrame();
        config.handler();
        updating = false;
    }

    public class Config
    {
        public Action handler;
        public BGId[] added;
        public BGId[] updated;
        public BGId[] deleted;
    }
}