﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//attach it to a chest
public class Chest : DbGoChest
{
    private Interactable interactable;

    public override void Start()
    {
        interactable = new Interactable(transform, new Vector3(0,.3f,0), "PRESS E TO OPEN", Open);
    }

    //======================== Open Chest
    private void Open()
    {
        UiManager.Open<WindowChest>().Entity = Entity;
    }

    //======================== Interaction with the player
    private void OnTriggerStay(Collider other)
    {
        interactable.OnTriggerStay(other);
    }

    private void OnTriggerExit(Collider other)
    {
        interactable.OnTriggerExit(other);
    }
}