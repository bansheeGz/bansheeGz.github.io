﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//attach it to a trader
public class Trader : DbGoTrader
{
    private Interactable interactable;

    public override void Start()
    {
        interactable = new Interactable(transform, new Vector3(0,1f,0), "PRESS E TO TRADE", Open);
    }

    //======================== Open Chest
    private void Open()
    {
        UiManager.Open<WindowTrade>().Entity = Entity;
    }

    //======================== Interaction with the player
    private void OnTriggerStay(Collider other)
    {
        interactable.OnTriggerStay(other);
    }

    private void OnTriggerExit(Collider other)
    {
        interactable.OnTriggerExit(other);
    }
}
