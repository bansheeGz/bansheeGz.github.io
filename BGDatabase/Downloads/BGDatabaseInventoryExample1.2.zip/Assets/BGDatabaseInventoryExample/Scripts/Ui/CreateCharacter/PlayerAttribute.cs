﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerAttribute : DbGoAbility
{
    public Text nameText;
    public Text levelText;
    public Button moreButton;
    public Button lessButton;

    public PointsController Controller { get; set; }

    public override void Start()
    {
        moreButton.onClick.AddListener(Add);
        lessButton.onClick.AddListener(Remove);
    }

    private void Add()
    {
        if (!Controller.Consume()) return;

        f_level++;
        UpdateUi();
    }

    private void Remove()
    {
        if (f_level < 2) return;

        Controller.Rollback();
        f_level--;
        UpdateUi();
    }

    private void UpdateUi()
    {
        levelText.text = "" + f_level;
    }


    public override void EntityChanged()
    {
        nameText.text = Entity.Name;
        UpdateUi();
    }

    public class PointsController
    {
        private readonly Func<int> availableFunc;
        private readonly Action consume;
        private readonly Action rollback;

        public int Available
        {
            get { return availableFunc(); }
        }

        public bool Consume()
        {
            if (Available <= 0) return false;
            consume();
            return true;
        }

        public void Rollback()
        {
            rollback();
        }

        public PointsController(Func<int> availableFunc, Action consume, Action rollback)
        {
            this.availableFunc = availableFunc;
            this.consume = consume;
            this.rollback = rollback;
        }
    }
}