# BG Database Binary Tool

A standalone command-line tool for reading and modifying BG Database binary files outside of Unity Editor.

## Purpose

This tool allows you to:
- Read values from BG Database binary files
- Modify values in BG Database binary files
- List tables and fields
- Select specific rows by index or field matching
- Batch update values for testing and balancing

All without requiring Unity Editor to be running.

## Requirements

- .NET 8.0 Runtime
- BG Database asset (for source code extraction)
- A BG Database binary file (usually `bansheegz_database.bytes`)

## Setup

1. Place the tool in your project directory
2. Run the PowerShell extraction script to extract required BG Database code:
   ```powershell
   cd bin
   ./extract-bgdb-code.ps1
   ```
3. Build the tool:
   ```bash
   dotnet build -c Release
   ```

## Usage

### Specify Database File

You can specify the database file in three ways:

1. **Command-line parameter:**
   ```bash
   bgdb-tool --db path/to/bansheegz_database.bytes <command>
   # or short form:
   bgdb-tool -d path/to/bansheegz_database.bytes <command>
   ```

2. **Environment variable:**
   ```bash
   export BGDB_PATH=path/to/bansheegz_database.bytes
   bgdb-tool <command>
   ```

3. **Default** (looks for `bansheegz_database.bytes` in current directory)

### Commands

#### List Commands

**List all tables:**
```bash
bgdb-tool list
```
Output: Shows all tables with entry counts

**List fields in a table:**
```bash
bgdb-tool list TableName
```
Output: Shows all fields with their values from the first row

#### Read Command

**Read a field value (first row by default):**
```bash
bgdb-tool read TableName.fieldName
```

**Read field from specific row by index:**
```bash
bgdb-tool read TableName[0].fieldName
bgdb-tool read TableName[2].fieldName
```

**Read field from row matching a condition:**
```bash
bgdb-tool read TableName[name="Blue God"].fieldName
bgdb-tool read TableName[id=LandChange].mana_cost
```

#### Write Command

**Write a field value (first row by default):**
```bash
bgdb-tool write TableName.fieldName=newValue
```

**Write to specific row by index:**
```bash
bgdb-tool write TableName[0].fieldName=newValue
```

**Write to row matching a condition:**
```bash
bgdb-tool write God[name="Blue God"].mana_factor=2
bgdb-tool write Actions[id=LandChange].mana_cost=300000
```

### Row Selectors

The tool supports three types of row selectors:

1. **No selector** - Uses the first row (index 0)
   ```bash
   bgdb-tool read God.mana_factor
   ```

2. **Index selector** - Select row by numeric index
   ```bash
   bgdb-tool read God[0].mana_factor
   bgdb-tool write Actions[2].mana_cost=500000
   ```

3. **Field match selector** - Select row where field equals value
   ```bash
   bgdb-tool read God[name="Blue God"].max_mana
   bgdb-tool write Actions[action_name="Flood"].mana_cost=5000000
   ```

## Examples

### Game Balance Examples

```bash
# Read current mana generation factor
bgdb-tool read God.mana_factor

# Update mana generation rate
bgdb-tool write God.mana_factor=2

# Check all action costs
bgdb-tool list Actions

# Update specific action cost by ID
bgdb-tool write Actions[id=LandChange].mana_cost=300000
bgdb-tool write Actions[action_name="Flood"].mana_cost=5000000

# Update initial mana for Blue God
bgdb-tool write God[name="Blue God"].initial_mana=1500000
```

### Using PowerShell Wrapper

The project includes a PowerShell wrapper script at `bin/bgdb.ps1`:

```powershell
# Uses the game's database automatically
./bin/bgdb.ps1 list
./bin/bgdb.ps1 read God.mana_factor
./bin/bgdb.ps1 write God.mana_factor=2
```

## How It Works

The tool extracts only the binary read/write code from BG Database, preserving the exact binary format. This ensures compatibility with Unity's BG Database runtime.

The extraction script (`extract-bgdb-code.ps1`) copies only the essential binary I/O classes and strips Unity dependencies, allowing the code to run standalone.

## Important Notes

- Always backup your database file before making changes
- The tool preserves BG Database's exact binary format
- Changes are immediately saved to the file
- Unity must be closed when modifying the database file

## Compatibility

This tool is compatible with BG Database 1.8.x - 1.9.x (binary format version 8).

## License

This tool uses code extracted from BG Database, which is subject to its own license.
The extraction and stub code are provided as-is for use with legally obtained BG Database assets.