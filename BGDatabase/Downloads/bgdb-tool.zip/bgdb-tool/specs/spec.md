# BGDB Tool Specification

**Feature ID**: bgdb-tool
**Feature Name**: Standalone BG Database Manipulation Tool
**Version**: 1.0
**Date Created**: 2025-09-14
**Author**: Claude

## Summary

Create a standalone command-line tool that can read and modify BG Database binary files without requiring Unity Editor, enabling automated balance iterations and CI/CD integration.

## Problem Statement

### Current Situation
- BG Database values can only be modified through Unity Editor
- Balance iterations require manual Unity interaction
- Cannot automate database changes for testing
- Unity batch mode interferes with running Editor instances
- No way to script database modifications for CI/CD

### Impact
- Slow iteration cycles for game balancing
- Manual process prone to errors
- Cannot integrate with automated testing pipelines
- Blocks parallel development when Unity is required

## Success Criteria

### Must Have
- [x] Read BG Database binary format (version 8)
- [x] Modify integer values (e.g., mana_factor)
- [x] Modify string values (e.g., names)
- [x] Save changes back to binary format
- [x] Preserve database integrity and structure
- [x] Command-line interface for automation

### Should Have
- [x] List all tables and fields
- [ ] Batch update multiple values
- [ ] Validation of value types and ranges
- [ ] Backup original database before changes
- [ ] JSON export/import for version control

## Functional Requirements

### FR-001: Binary Format Support
The tool MUST read and write BG Database binary format version 8 without data loss.

### FR-002: Field Modification
The tool MUST support modifying:
- Integer fields (int32, int64)
- Float fields (float32)
- String fields
- Boolean fields

### FR-003: Command-Line Interface
The tool MUST provide CLI commands for:
- `read <table>.<field>` - Read a specific value (first row)
- `read <table>[index].<field>` - Read from specific row by index
- `read <table>[id=value].<field>` - Read from row matching id
- `write <table>.<field>=<value>` - Write to first row
- `write <table>[index].<field>=<value>` - Write to specific row by index
- `write <table>[id=value].<field>=<value>` - Write to row matching id
- `list [table]` - List tables or fields in a table
- `backup` - Create a backup of current database

### FR-004: Data Integrity
The tool MUST:
- Preserve all unmodified data exactly
- Maintain field type consistency
- Validate value ranges where applicable
- Refuse operations that would corrupt the database

### FR-005: Cross-Platform
The tool MUST run on:
- Windows (native and WSL)
- Linux
- macOS

### FR-006: Performance
The tool MUST:
- Load database in < 1 second
- Save changes in < 1 second
- Handle databases up to 100MB

## Non-Functional Requirements

### NFR-001: Reliability
- Zero data corruption rate
- Automatic backup before modifications
- Clear error messages for invalid operations

### NFR-002: Maintainability
- Minimal dependencies (no Unity required)
- Clean separation from BG Database internals
- Documented extraction/update process

### NFR-003: Usability
- Self-documenting CLI with --help
- Clear success/failure feedback
- Example scripts for common operations

## Implementation Notes (Added 2025-09-14)

### Actual Implementation
Instead of extracting source code, we used BGDatabase.dll directly:
- **BGDatabase.dll**: Referenced the compiled runtime DLL
- **UnityEngine.dll**: Created minimal stub with Unity types
- **100% Compatibility**: Using actual DLL ensures binary format compatibility

### Current Status
- ✅ Reading database files works
- ✅ Listing tables and fields works
- ✅ Basic field modifications work (first row only)
- ❌ Row selection not yet implemented
- ✅ Write functionality validated with real databases
- ✅ Unity type stubs expanded for common types

## Technical Constraints

### Dependencies
- .NET 8.0 runtime
- BGDatabase.dll (included in lib/)
- UnityEngine.dll stub (built from UnityStubs/)

### Compatibility
- Works with BG Database compiled DLLs
- Handles standard BG Database field types
- Preserves addon-specific data

## Out of Scope

- Modifying database schema/structure
- Creating new tables or fields
- Handling encrypted databases
- Real-time database synchronization
- Unity asset references (prefabs, textures, etc.)

## Risks and Mitigations

| Risk | Impact | Mitigation |
|------|--------|------------|
| BG Database format changes | Tool breaks | Version detection and compatibility modes |
| Data corruption | Lost work | Mandatory backups, validation |
| Unity-specific types | Cannot process | Stub implementations for basic types |
| Complex field types | Limited functionality | Focus on primitive types first |

## Acceptance Criteria

1. **Basic Operations**
   - Can read any field value from database
   - Can change field values with type preservation
   - Can save changes and Unity loads modified database

2. **Batch Operations**
   - Can update multiple fields in one command
   - Can apply iteration scripts for balance testing

3. **Integration**
   - Can be called from bash/PowerShell scripts
   - Can be integrated into CI/CD pipelines
   - Works alongside running Unity Editor

## Example Usage

```bash
# Read current value (first row)
./bgdb-tool read God.max_mana
> God.max_mana = 25000000

# Read from specific row by index
./bgdb-tool read God[2].max_mana
> God[2].max_mana = 25000000

# Read from row matching id
./bgdb-tool read God[id=2].max_mana
> God[id=2].max_mana = 25000000

# Write to specific row
./bgdb-tool write God[name="Yellow God"].max_mana=30000000
> Updated God[name="Yellow God"].max_mana: 25000000 -> 30000000

# List all fields in a table (shows first row)
./bgdb-tool list God
> God.name = Blue God
> God.id = 0
> God.max_mana = 25000000
```

## Success Metrics

- Reduce balance iteration time from 5 minutes to 30 seconds
- Enable automated testing of 10+ balance configurations
- Zero database corruption incidents
- Adoption by game designers for balance testing