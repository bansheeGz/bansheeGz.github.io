# Tasks — BGDB Tool

**Status**: COMPLETED
**Completion Date**: 2025-09-14
**Actual Implementation**: Using BGDatabase.dll directly with comprehensive Unity stubs

## Implementation Summary
Successfully created a standalone tool that can read/write BG Database binary files without Unity by using the compiled BGDatabase.dll directly with minimal Unity type stubs.

## Core Approach (What We Actually Did)
- Used the compiled BGDatabase.dll directly (no source extraction)
- Created minimal UnityEngine.dll stub with basic Unity types
- Built standalone .NET 8.0 console application
- Tool is completely project-agnostic and shareable

## Actual Implementation Tasks

## T001. Setup BGDatabase.dll reference ✅
- Status: COMPLETED
- Result: Copied BGDatabase.dll to lib/ folder and referenced in project

## T002. Create Unity type stubs ✅
- Path: UnityStubs/UnityEngine.cs
- Status: COMPLETED
- Result: Created minimal UnityEngine.dll with basic Unity types (Vector3, Color, etc.)

## T003. Implement database loading ✅
- Path: Commands/DatabaseLoader.cs
- Status: COMPLETED
- Result: Can load BG Database binary files using BGDatabase.dll

## T004. Implement field navigation ✅
- Path: Commands/FieldNavigator.cs
- Status: COMPLETED
- Result: Can navigate to any Table.field path

## T005. Implement read command ✅
- Status: COMPLETED (in Program.cs)
- Result: Can read and display field values

## T006. Implement set command ✅
- Status: COMPLETED (in Program.cs)
- Result: Can change field values and save

## T007. Implement list command ✅
- Status: COMPLETED (in Program.cs)
- Result: Can list tables and fields

## T008. Build and package tool ✅
- Status: COMPLETED
- Result: Tool builds with .NET 8.0 and runs standalone

## Outstanding Tasks

## T009. Expand Unity type stubs ✅
- Status: COMPLETED
- Note: Added all required Unity types (Ray2D, KeyCode, Gradient, Object hierarchy, Components, etc.)

## T010. Test write functionality thoroughly ✅
- Status: COMPLETED
- Note: Successfully tested reading and writing various field types (int, float, string) on real databases

## T011. Add backup functionality
- Status: NOT IMPLEMENTED (optional)
- Note: Manual backup recommended for now

## T012. Create batch command processor
- Status: NOT IMPLEMENTED (optional)
- Note: Single commands work; batch can be added later

---

## Key Architecture Decisions

### Why BGDatabase.dll Instead of Source Extraction?
- **100% Binary Compatibility**: Using the actual compiled DLL guarantees compatibility
- **No Maintenance**: No need to maintain extracted/modified source code
- **Simpler**: Avoids complex dependency extraction
- **Updatable**: Can swap in new BGDatabase.dll versions easily

### Minimal Unity Stubs
- Only stub types that are actually used
- Keep stubs as simple as possible (empty classes/structs)
- Build UnityEngine.dll with matching version signature

## Success Criteria
✅ Can read field values from database
✅ Can list tables and fields
✅ Can modify field values and save changes
✅ Tool runs without Unity installation
✅ Write functionality validated with real databases
✅ Complex Unity types fully stubbed

## Known Limitations
1. Cannot handle Unity asset references (prefabs, textures, ScriptableObjects) - only primitive types
2. Some advanced Unity types may require additional stubbing if encountered

## Outstanding Implementation Tasks

## T013. Implement row selection for read/write operations ❌
- Status: NOT IMPLEMENTED (CRITICAL)
- Problem: Currently only updates first row (index 0) of any table
- Priority: HIGH - Multiple rows exist in tables like God (6 entries)

### Implementation Steps:

1. **Create RowSelector.cs**
   ```csharp
   public class RowSelector
   {
       public enum SelectorType { Index, FieldMatch, First }
       public SelectorType Type { get; set; }
       public int? Index { get; set; }
       public string FieldName { get; set; }
       public object FieldValue { get; set; }

       public static RowSelector Parse(string selector)
       public BGEntity SelectRow(BGMetaEntity meta)
   }
   ```

2. **Update FieldNavigator.cs**
   - Add `RowSelector` parameter to `NavigateToField` method
   - Use selector to find correct entity instead of always using index 0
   - Modify `GetFieldValue` and `SetFieldValue` to accept row selector

3. **Update Program.cs**
   - Add regex pattern: `^([^[]+)(?:\[([^\]]+)\])?\.(.+)$`
   - Parse field path to extract table, selector, and field
   - Create RowSelector from parsed selector string
   - Pass selector to FieldNavigator methods

4. **Test Cases**
   - `God.max_mana` - Should read/write first row (Blue God)
   - `God[2].max_mana` - Should read/write third row (Yellow God)
   - `God[id=2].max_mana` - Should find row where id=2
   - `God[name="Yellow God"].max_mana` - Should find row by name
   - Error handling for invalid indices or non-matching selectors

## Next Steps
1. Implement row selection (T013) - CRITICAL
2. Package as standalone executable for distribution
3. Create automated tests for regression testing
4. Consider adding batch command support for multiple operations