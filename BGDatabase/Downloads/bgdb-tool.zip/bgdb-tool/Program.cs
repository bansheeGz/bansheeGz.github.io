using System;
using System.IO;
using System.Text.RegularExpressions;
using BGDBTool.Commands;

namespace BGDBTool
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length == 0)
            {
                ShowHelp();
                return;
            }

            // Database path can be set via environment variable or command line
            var databasePath = Environment.GetEnvironmentVariable("BGDB_PATH") ??
                              "bansheegz_database.bytes";

            // Allow override via --db parameter
            for (int i = 0; i < args.Length - 1; i++)
            {
                if (args[i] == "--db" || args[i] == "-d")
                {
                    databasePath = args[i + 1];
                    // Remove these args from the array
                    var newArgs = new string[args.Length - 2];
                    Array.Copy(args, 0, newArgs, 0, i);
                    Array.Copy(args, i + 2, newArgs, i, args.Length - i - 2);
                    args = newArgs;
                    break;
                }
            }

            if (!File.Exists(databasePath))
            {
                Console.WriteLine($"Database file not found: {databasePath}");
                Console.WriteLine("Use --db <path> to specify database location");
                Console.WriteLine("Or set BGDB_PATH environment variable");
                return;
            }

            if (args.Length == 0)
            {
                ShowHelp();
                return;
            }

            var command = args[0].ToLower();

            switch (command)
            {
                case "read":
                    if (args.Length < 2)
                    {
                        Console.WriteLine("Usage: bgdb-tool read <field-path>");
                        return;
                    }
                    ReadValue(databasePath, args[1]);
                    break;

                case "write":
                    if (args.Length < 2)
                    {
                        Console.WriteLine("Usage: bgdb-tool write <field-path>=<value>");
                        return;
                    }
                    SetValue(databasePath, args[1]);
                    break;

                case "list":
                    ListTables(databasePath, args.Length > 1 ? args[1] : null);
                    break;

                default:
                    Console.WriteLine($"Unknown command: {command}");
                    ShowHelp();
                    break;
            }
        }

        static void ShowHelp()
        {
            Console.WriteLine("BGDBTool - BG Database Binary Manipulation Tool");
            Console.WriteLine("A standalone tool for reading and modifying BG Database binary files");
            Console.WriteLine();
            Console.WriteLine("Usage:");
            Console.WriteLine("  bgdb-tool [--db <path>] <command> [arguments]");
            Console.WriteLine();
            Console.WriteLine("Database Path:");
            Console.WriteLine("  --db <path>, -d <path>    Specify database file path");
            Console.WriteLine("  BGDB_PATH env variable    Set default database path");
            Console.WriteLine("  Default: bansheegz_database.bytes in current directory");
            Console.WriteLine();
            Console.WriteLine("Commands:");
            Console.WriteLine("  read <table.field>         Read a field value");
            Console.WriteLine("  write <table.field>=<val>  Write a field value");
            Console.WriteLine("  list [table]               List tables or fields in a table");
            Console.WriteLine();
            Console.WriteLine("Examples:");
            Console.WriteLine("  bgdb-tool --db Assets/Resources/bansheegz_database.bytes list");
            Console.WriteLine("  bgdb-tool read MyTable.myField");
            Console.WriteLine("  bgdb-tool write MyTable.myField=42");
        }

        static (string tableName, string fieldName, RowSelector rowSelector) ParseFieldPath(string fieldPath)
        {
            // Pattern: Table[selector].field or Table.field
            var pattern = @"^([^[]+)(?:\[([^\]]+)\])?\.(.+)$";
            var match = Regex.Match(fieldPath, pattern);

            if (!match.Success)
            {
                throw new ArgumentException($"Invalid field path format: {fieldPath}");
            }

            string tableName = match.Groups[1].Value;
            string selectorStr = match.Groups[2].Value; // May be empty
            string fieldName = match.Groups[3].Value;

            var rowSelector = RowSelector.Parse(selectorStr);

            return (tableName, fieldName, rowSelector);
        }

        static void ReadValue(string databasePath, string fieldPath)
        {
            try
            {
                var loader = new DatabaseLoader(databasePath);
                var repo = loader.LoadDatabase();
                var navigator = new FieldNavigator(repo);

                var (tableName, fieldName, rowSelector) = ParseFieldPath(fieldPath);
                var value = navigator.GetFieldValue(tableName, fieldName, rowSelector);

                // Format output with row selector if present
                var selectorStr = rowSelector.GetDescription();
                var outputPath = $"{tableName}{selectorStr}.{fieldName}";
                Console.WriteLine($"{outputPath} = {value}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        static void SetValue(string databasePath, string assignment)
        {
            // Find the last = sign for the value assignment (to handle selectors with =)
            var lastEquals = assignment.LastIndexOf('=');
            if (lastEquals < 0)
            {
                Console.WriteLine("Invalid assignment format. Use: field-path=value");
                return;
            }

            var fieldPath = assignment.Substring(0, lastEquals);
            var valueStr = assignment.Substring(lastEquals + 1);

            try
            {
                var loader = new DatabaseLoader(databasePath);
                var repo = loader.LoadDatabase();
                var navigator = new FieldNavigator(repo);

                var (tableName, fieldName, rowSelector) = ParseFieldPath(fieldPath);
                var info = navigator.NavigateToField(tableName, fieldName, rowSelector);
                var currentValue = info.Field.GetValue(info.Entity);

                object newValue;
                if (currentValue is int)
                    newValue = int.Parse(valueStr);
                else if (currentValue is float)
                    newValue = float.Parse(valueStr);
                else if (currentValue is bool)
                    newValue = bool.Parse(valueStr);
                else
                    newValue = valueStr;

                navigator.SetFieldValue(tableName, fieldName, rowSelector, newValue);

                // Format output with row selector if present
                var selectorStr = rowSelector.GetDescription();
                var outputPath = $"{tableName}{selectorStr}.{fieldName}";
                Console.WriteLine($"Updated {outputPath}: {currentValue} -> {newValue}");

                loader.SaveDatabase(repo);
                Console.WriteLine("Database saved successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        static void ListTables(string databasePath, string tableName)
        {
            try
            {
                var loader = new DatabaseLoader(databasePath);
                var repo = loader.LoadDatabase();

                if (string.IsNullOrEmpty(tableName))
                {
                    Console.WriteLine("Tables in database:");
                    repo.ForEachMeta(meta =>
                    {
                        Console.WriteLine($"  {meta.Name} ({meta.CountEntities} entries)");
                    });
                }
                else
                {
                    var meta = repo.GetMeta(tableName);
                    if (meta == null)
                    {
                        Console.WriteLine($"Table not found: {tableName}");
                        return;
                    }

                    Console.WriteLine($"Fields in {tableName}:");
                    meta.ForEachField(field =>
                    {
                        if (meta.CountEntities > 0)
                        {
                            var entity = meta.GetEntity(0);
                            var value = field.GetValue(entity);
                            Console.WriteLine($"  {field.Name} = {value}");
                        }
                        else
                        {
                            Console.WriteLine($"  {field.Name} (no data)");
                        }
                    });
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }
    }
}