using System;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using BGDBTool.Commands;

namespace BGDBTool
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length == 0)
            {
                ShowHelp();
                return;
            }

            // Database path can be set via environment variable or command line
            var databasePath = Environment.GetEnvironmentVariable("BGDB_PATH") ??
                              "bansheegz_database.bytes";

            // Allow override via --db parameter
            for (int i = 0; i < args.Length - 1; i++)
            {
                if (args[i] == "--db" || args[i] == "-d")
                {
                    databasePath = args[i + 1];
                    // Remove these args from the array
                    var newArgs = new string[args.Length - 2];
                    Array.Copy(args, 0, newArgs, 0, i);
                    Array.Copy(args, i + 2, newArgs, i, args.Length - i - 2);
                    args = newArgs;
                    break;
                }
            }

            if (!File.Exists(databasePath))
            {
                Console.WriteLine($"Database file not found: {databasePath}");
                Console.WriteLine("Use --db <path> to specify database location");
                Console.WriteLine("Or set BGDB_PATH environment variable");
                return;
            }

            if (args.Length == 0)
            {
                ShowHelp();
                return;
            }

            var command = args[0].ToLower();

            switch (command)
            {
                case "read":
                    if (args.Length < 2)
                    {
                        Console.WriteLine("Usage: bgdb-tool read <field-path>");
                        return;
                    }
                    ReadValue(databasePath, args[1]);
                    break;

                case "write":
                    if (args.Length < 2)
                    {
                        Console.WriteLine("Usage: bgdb-tool write <field-path>=<value>");
                        return;
                    }
                    SetValue(databasePath, args[1]);
                    break;

                case "list":
                    ListTables(databasePath, args.Length > 1 ? args[1] : null);
                    break;

                case "create-table":
                    if (args.Length < 2)
                    {
                        Console.WriteLine("Usage: bgdb-tool create-table <table-name>");
                        return;
                    }
                    CreateTable(databasePath, args[1]);
                    break;

                case "rename-table":
                    if (args.Length < 3)
                    {
                        Console.WriteLine("Usage: bgdb-tool rename-table <old-name> <new-name>");
                        return;
                    }
                    RenameTable(databasePath, args[1], args[2]);
                    break;

                case "add-fields":
                    if (args.Length < 3)
                    {
                        Console.WriteLine("Usage: bgdb-tool add-fields <table-name> <field1:type> [field2:type] ...");
                        return;
                    }
                    var tableName = args[1];
                    var fieldDefs = args.Skip(2).ToArray();
                    AddFields(databasePath, tableName, fieldDefs);
                    break;

                default:
                    Console.WriteLine($"Unknown command: {command}");
                    ShowHelp();
                    break;
            }
        }

        static void ShowHelp()
        {
            Console.WriteLine("BGDBTool - BG Database Binary Manipulation Tool");
            Console.WriteLine("A standalone tool for reading and modifying BG Database binary files");
            Console.WriteLine();
            Console.WriteLine("Usage:");
            Console.WriteLine("  bgdb-tool [--db <path>] <command> [arguments]");
            Console.WriteLine();
            Console.WriteLine("Database Path:");
            Console.WriteLine("  --db <path>, -d <path>    Specify database file path");
            Console.WriteLine("  BGDB_PATH env variable    Set default database path");
            Console.WriteLine("  Default: bansheegz_database.bytes in current directory");
            Console.WriteLine();
            Console.WriteLine("Commands:");
            Console.WriteLine("  read <table.field>         Read a field value");
            Console.WriteLine("  write <table.field>=<val>  Write a field value");
            Console.WriteLine("  list [table]               List tables or fields in a table");
            Console.WriteLine("  create-table <name>        Create a new table");
            Console.WriteLine("  rename-table <old> <new>   Rename an existing table");
            Console.WriteLine("  add-fields <table> <field:type>... Add fields to a table");
            Console.WriteLine();
            Console.WriteLine("Field Types: int, float, string, bool");
            Console.WriteLine();
            Console.WriteLine("Examples:");
            Console.WriteLine("  bgdb-tool --db Assets/Resources/bansheegz_database.bytes list");
            Console.WriteLine("  bgdb-tool read MyTable.myField");
            Console.WriteLine("  bgdb-tool write MyTable.myField=42");
            Console.WriteLine("  bgdb-tool create-table God");
            Console.WriteLine("  bgdb-tool add-fields God max_mana:float initial_mana:float");
            Console.WriteLine("  bgdb-tool rename-table Map Maps");
        }

        static (string tableName, string fieldName, RowSelector rowSelector) ParseFieldPath(string fieldPath)
        {
            // Pattern: Table[selector].field or Table.field
            var pattern = @"^([^[]+)(?:\[([^\]]+)\])?\.(.+)$";
            var match = Regex.Match(fieldPath, pattern);

            if (!match.Success)
            {
                throw new ArgumentException($"Invalid field path format: {fieldPath}");
            }

            string tableName = match.Groups[1].Value;
            string selectorStr = match.Groups[2].Value; // May be empty
            string fieldName = match.Groups[3].Value;

            var rowSelector = RowSelector.Parse(selectorStr);

            return (tableName, fieldName, rowSelector);
        }

        static void ReadValue(string databasePath, string fieldPath)
        {
            try
            {
                var loader = new DatabaseLoader(databasePath);
                var repo = loader.LoadDatabase();
                var navigator = new FieldNavigator(repo);

                var (tableName, fieldName, rowSelector) = ParseFieldPath(fieldPath);
                var value = navigator.GetFieldValue(tableName, fieldName, rowSelector);

                // Format output with row selector if present
                var selectorStr = rowSelector.GetDescription();
                var outputPath = $"{tableName}{selectorStr}.{fieldName}";
                Console.WriteLine($"{outputPath} = {value}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        static void SetValue(string databasePath, string assignment)
        {
            // Find the last = sign for the value assignment (to handle selectors with =)
            var lastEquals = assignment.LastIndexOf('=');
            if (lastEquals < 0)
            {
                Console.WriteLine("Invalid assignment format. Use: field-path=value");
                return;
            }

            var fieldPath = assignment.Substring(0, lastEquals);
            var valueStr = assignment.Substring(lastEquals + 1);

            try
            {
                var loader = new DatabaseLoader(databasePath);
                var repo = loader.LoadDatabase();
                var navigator = new FieldNavigator(repo);

                var (tableName, fieldName, rowSelector) = ParseFieldPath(fieldPath);
                var info = navigator.NavigateToField(tableName, fieldName, rowSelector);
                var currentValue = info.Field.GetValue(info.Entity);

                object newValue;
                if (currentValue is int)
                    newValue = int.Parse(valueStr);
                else if (currentValue is float)
                    newValue = float.Parse(valueStr);
                else if (currentValue is bool)
                    newValue = bool.Parse(valueStr);
                else
                    newValue = valueStr;

                navigator.SetFieldValue(tableName, fieldName, rowSelector, newValue);

                // Format output with row selector if present
                var selectorStr = rowSelector.GetDescription();
                var outputPath = $"{tableName}{selectorStr}.{fieldName}";
                Console.WriteLine($"Updated {outputPath}: {currentValue} -> {newValue}");

                loader.SaveDatabase(repo);
                Console.WriteLine("Database saved successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        static void ListTables(string databasePath, string tableName)
        {
            try
            {
                var loader = new DatabaseLoader(databasePath);
                var repo = loader.LoadDatabase();

                if (string.IsNullOrEmpty(tableName))
                {
                    Console.WriteLine("Tables in database:");
                    repo.ForEachMeta(meta =>
                    {
                        Console.WriteLine($"  {meta.Name} ({meta.CountEntities} entries)");
                    });
                }
                else
                {
                    var meta = repo.GetMeta(tableName);
                    if (meta == null)
                    {
                        Console.WriteLine($"Table not found: {tableName}");
                        return;
                    }

                    // Show all rows in the table
                    for (int i = 0; i < meta.CountEntities; i++)
                    {
                        Console.WriteLine($"\nRow {i}:");
                        var entity = meta.GetEntity(i);
                        meta.ForEachField(field =>
                        {
                            var value = field.GetValue(entity);
                            Console.WriteLine($"  {field.Name} = {value}");
                        });
                    }

                    if (meta.CountEntities == 0)
                    {
                        Console.WriteLine("No entries in this table");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        static void CreateTable(string databasePath, string tableName)
        {
            try
            {
                var loader = new DatabaseLoader(databasePath);
                var repo = loader.LoadDatabase();
                var tableManager = new TableManager(repo);

                // Check if this should be a config table (single row)
                bool isConfigTable = tableName == "God" || tableName == "Follower" || tableName == "House";

                if (isConfigTable)
                {
                    tableManager.CreateConfigTable(tableName);
                }
                else
                {
                    tableManager.CreateTable(tableName);
                }

                loader.SaveDatabase(repo);
                Console.WriteLine("Database saved successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        static void RenameTable(string databasePath, string oldName, string newName)
        {
            try
            {
                var loader = new DatabaseLoader(databasePath);
                var repo = loader.LoadDatabase();
                var tableManager = new TableManager(repo);

                tableManager.RenameTable(oldName, newName);

                loader.SaveDatabase(repo);
                Console.WriteLine("Database saved successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        static void AddFields(string databasePath, string tableName, string[] fieldDefinitions)
        {
            try
            {
                var loader = new DatabaseLoader(databasePath);
                var repo = loader.LoadDatabase();
                var tableManager = new TableManager(repo);

                tableManager.AddFields(tableName, fieldDefinitions);

                loader.SaveDatabase(repo);
                Console.WriteLine("Database saved successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }
    }
}