using System;
using System.Text.RegularExpressions;
using BansheeGz.BGDatabase;

namespace BGDBTool.Commands
{
    public class RowSelector
    {
        public enum SelectorType { Index, FieldMatch, First }

        public SelectorType Type { get; set; }
        public int? Index { get; set; }
        public string? FieldName { get; set; }
        public string? FieldValue { get; set; }

        public static RowSelector Parse(string? selector)
        {
            if (string.IsNullOrEmpty(selector))
            {
                return new RowSelector { Type = SelectorType.First };
            }

            // Check if it's a pure number (index selector)
            if (int.TryParse(selector, out int index))
            {
                return new RowSelector
                {
                    Type = SelectorType.Index,
                    Index = index
                };
            }

            // Check if it's a field match selector (field=value)
            var match = Regex.Match(selector, @"^(\w+)=(.+)$");
            if (match.Success)
            {
                var fieldName = match.Groups[1].Value;
                var fieldValue = match.Groups[2].Value;

                // Remove quotes if present
                if (fieldValue.StartsWith("\"") && fieldValue.EndsWith("\""))
                {
                    fieldValue = fieldValue.Substring(1, fieldValue.Length - 2);
                }

                return new RowSelector
                {
                    Type = SelectorType.FieldMatch,
                    FieldName = fieldName,
                    FieldValue = fieldValue
                };
            }

            throw new ArgumentException($"Invalid row selector format: [{selector}]");
        }

        public BGEntity SelectRow(BGMetaEntity meta)
        {
            switch (Type)
            {
                case SelectorType.Index:
                    if (Index >= meta.CountEntities)
                    {
                        throw new ArgumentException($"Index {Index} is out of range. Table has {meta.CountEntities} rows.");
                    }
                    return meta.GetEntity(Index.Value);

                case SelectorType.FieldMatch:
                    // Find the field to match on
                    BGField? matchField = null;
                    meta.ForEachField(field =>
                    {
                        if (field.Name.Equals(FieldName, StringComparison.OrdinalIgnoreCase))
                        {
                            matchField = field;
                        }
                    });

                    if (matchField == null)
                    {
                        throw new ArgumentException($"Field '{FieldName}' not found in table '{meta.Name}'");
                    }

                    // Find the entity with matching value
                    for (int i = 0; i < meta.CountEntities; i++)
                    {
                        var entity = meta.GetEntity(i);
                        var value = matchField.GetValue(entity);

                        // Convert value to string for comparison
                        string valueStr = value?.ToString() ?? "";

                        if (valueStr.Equals(FieldValue, StringComparison.OrdinalIgnoreCase))
                        {
                            return entity;
                        }
                    }

                    throw new ArgumentException($"No row found where {FieldName}='{FieldValue}'");

                case SelectorType.First:
                default:
                    if (meta.CountEntities == 0)
                    {
                        throw new ArgumentException($"Table '{meta.Name}' has no rows");
                    }
                    return meta.GetEntity(0);
            }
        }

        public string GetDescription()
        {
            switch (Type)
            {
                case SelectorType.Index:
                    return $"[{Index}]";
                case SelectorType.FieldMatch:
                    return $"[{FieldName}=\"{FieldValue}\"]";
                case SelectorType.First:
                default:
                    return "";
            }
        }
    }
}