using System;
using System.IO;
using BansheeGz.BGDatabase;

namespace BGDBTool.Commands
{
    public class DatabaseLoader
    {
        private readonly string _databasePath;
        private BGRepo _repo;

        public DatabaseLoader(string databasePath)
        {
            _databasePath = databasePath;
        }

        public BGRepo LoadDatabase()
        {
            if (!File.Exists(_databasePath))
            {
                throw new FileNotFoundException($"Database file not found: {_databasePath}");
            }

            byte[] bytes = File.ReadAllBytes(_databasePath);
            Console.WriteLine($"Loaded {bytes.Length} bytes from database");

            if (bytes.Length < 4)
            {
                throw new InvalidOperationException($"Database file too small: {bytes.Length} bytes");
            }

            // Check version
            var version = BitConverter.ToInt32(bytes, 0);
            Console.WriteLine($"Database version: {version}");

            // Check for text format (JSON)
            if (bytes[0] == '{')
            {
                Console.WriteLine("Database appears to be in JSON format");
            }

            try
            {
                var binaryReader = new BGRepoBinary();
                _repo = binaryReader.Read(bytes);

                Console.WriteLine($"Successfully loaded database");
                return _repo;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading database at byte position: {ex.Message}");
                Console.WriteLine($"Stack trace: {ex.StackTrace}");
                throw;
            }
        }

        public void SaveDatabase(BGRepo repo)
        {
            var binaryWriter = new BGRepoBinary();
            var bytes = binaryWriter.Write(repo);
            File.WriteAllBytes(_databasePath, bytes);
        }
    }
}