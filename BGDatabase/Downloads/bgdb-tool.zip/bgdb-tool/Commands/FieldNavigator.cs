using System;
using System.Linq;
using BansheeGz.BGDatabase;

namespace BGDBTool.Commands
{
    public class FieldNavigator
    {
        private readonly BGRepo _repo;

        public FieldNavigator(BGRepo repo)
        {
            _repo = repo;
        }

        public FieldInfo NavigateToField(string tableName, string fieldName, RowSelector rowSelector)
        {
            var meta = _repo.GetMeta(tableName);
            if (meta == null)
            {
                throw new ArgumentException($"Table not found: {tableName}");
            }

            var field = meta.GetField(fieldName);
            if (field == null)
            {
                throw new ArgumentException($"Field not found: {fieldName} in table {tableName}");
            }

            var entity = rowSelector.SelectRow(meta);

            return new FieldInfo
            {
                Meta = meta,
                Field = field,
                Entity = entity,
                TableName = tableName,
                FieldName = fieldName,
                RowSelector = rowSelector
            };
        }

        public object GetFieldValue(string tableName, string fieldName, RowSelector rowSelector)
        {
            var info = NavigateToField(tableName, fieldName, rowSelector);
            return info.Field.GetValue(info.Entity);
        }

        public void SetFieldValue(string tableName, string fieldName, RowSelector rowSelector, object value)
        {
            var info = NavigateToField(tableName, fieldName, rowSelector);
            info.Field.SetValue(info.Entity, value);
        }
    }

    public class FieldInfo
    {
        public BGMetaEntity Meta { get; set; }
        public BGField Field { get; set; }
        public BGEntity Entity { get; set; }
        public string TableName { get; set; }
        public string FieldName { get; set; }
        public RowSelector RowSelector { get; set; }
    }
}