using System;
using System.Linq;
using BansheeGz.BGDatabase;

namespace BGDBTool.Commands
{
    /// <summary>
    /// Manages table operations: create, rename, delete
    /// </summary>
    public class TableManager
    {
        private readonly BGRepo _repo;

        public TableManager(BGRepo repo)
        {
            _repo = repo;
        }

        /// <summary>
        /// Create a new table
        /// </summary>
        public void CreateTable(string tableName)
        {
            // Check if table already exists
            if (_repo.GetMeta(tableName) != null)
            {
                throw new InvalidOperationException($"Table '{tableName}' already exists");
            }

            // Create a new BGMetaRow (standard table type)
            var newMeta = new BGMetaRow(_repo, tableName);

            Console.WriteLine($"Created table: {tableName}");
        }

        /// <summary>
        /// Rename an existing table
        /// </summary>
        public void RenameTable(string oldName, string newName)
        {
            var meta = _repo.GetMeta(oldName);
            if (meta == null)
            {
                throw new InvalidOperationException($"Table '{oldName}' not found");
            }

            // Check if new name already exists
            if (_repo.GetMeta(newName) != null)
            {
                throw new InvalidOperationException($"Table '{newName}' already exists");
            }

            // Update the name
            meta.Name = newName;

            Console.WriteLine($"Renamed table: {oldName} -> {newName}");
        }

        /// <summary>
        /// Delete a table (use with caution!)
        /// </summary>
        public void DeleteTable(string tableName)
        {
            var meta = _repo.GetMeta(tableName);
            if (meta == null)
            {
                throw new InvalidOperationException($"Table '{tableName}' not found");
            }

            // Delete the table (this will unregister it from repo)
            meta.Delete();

            Console.WriteLine($"Deleted table: {tableName}");
        }

        /// <summary>
        /// Add fields to a table
        /// </summary>
        public void AddFields(string tableName, string[] fieldDefinitions)
        {
            var meta = _repo.GetMeta(tableName);
            if (meta == null)
            {
                throw new InvalidOperationException($"Table '{tableName}' not found");
            }

            foreach (var fieldDef in fieldDefinitions)
            {
                var parts = fieldDef.Split(':');
                if (parts.Length != 2)
                {
                    throw new ArgumentException($"Invalid field definition: {fieldDef}. Use format 'name:type'");
                }

                var fieldName = parts[0].Trim();
                var fieldType = parts[1].Trim().ToLower();

                // Check if field already exists
                if (meta.GetField(fieldName, false) != null)
                {
                    Console.WriteLine($"Field '{fieldName}' already exists in table '{tableName}', skipping");
                    continue;
                }

                // Create field based on type
                BGField newField = fieldType switch
                {
                    "int" => new BGFieldInt(meta, fieldName),
                    "float" => new BGFieldFloat(meta, fieldName),
                    "string" => new BGFieldString(meta, fieldName),
                    "bool" => new BGFieldBool(meta, fieldName),
                    _ => throw new ArgumentException($"Unknown field type: {fieldType}")
                };

                Console.WriteLine($"Added field '{fieldName}' ({fieldType}) to table '{tableName}'");
            }
        }

        /// <summary>
        /// Create a single-row configuration table with initial row
        /// </summary>
        public void CreateConfigTable(string tableName)
        {
            CreateTable(tableName);

            var meta = _repo.GetMeta(tableName);
            if (meta is BGMetaRow rowMeta)
            {
                // Create the first (and only) row for config table
                if (rowMeta.CountEntities == 0)
                {
                    rowMeta.NewEntity();
                    Console.WriteLine($"Created initial row in config table: {tableName}");
                }
            }
        }
    }
}