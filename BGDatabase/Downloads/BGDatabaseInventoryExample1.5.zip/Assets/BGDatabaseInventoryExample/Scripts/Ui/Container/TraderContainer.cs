//container for a trader

using System;

//trader container
public struct TraderContainer
{
    private const int maxSize = 10;
    private readonly DbTrader trader;
    public TraderContainer(DbTrader trader) => this.trader = trader ?? throw new Exception("trader can not be null");

    //adding item to trader inventory
    public bool TryToAdd(DbItem item)
    {
        if (item?.f_item == null) throw new Exception("item can not be null");
        var maxStack = item.f_item.f_stack;
        return maxStack > 1 ? AddStackable(item, maxStack) : AddNonStackable(item);
    }

    private bool AddStackable(DbItem item, int maxStack)
    {
        var traderItems = trader.RelatedItemListUsinglocationRelation;
        foreach (var traderItem in traderItems)
        {
            if (!Equals(traderItem.f_item, item.f_item)) continue;
            if (traderItem.f_count >= maxStack) continue;
            traderItem.f_count += 1;
            if (item.f_count >= 2) item.f_count -= 1;
            else item.Delete();
            return true;
        }
        return AddNonStackable(item);
    }

    private bool AddNonStackable(DbItem item)
    {
        var traderItems = trader.RelatedItemListUsinglocationRelation;
        if (traderItems.Count >= maxSize) return false;
        if(item.f_count<=1) item.f_location = trader;
        else
        {
            item.f_count -= 1;
            var location = trader;
            DbItem.NewEntity(dbItem =>
            {
                dbItem.f_location = location;
                dbItem.f_count = 1;
                dbItem.f_item = item.f_item;
            });
        }
        return true;
    }
}