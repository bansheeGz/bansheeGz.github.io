using System;
using System.Collections.Generic;
using BansheeGz.BGDatabase;
using UnityEngine;

//container for inventory
public struct InventoryContainer
{
    //this is a reusable list to get rid of GC
    private static readonly List<DbInventory> List = new List<DbInventory>();

    //try to add item to inventory. Return the number of items which was not added (inventory is full)
    public int TryToAdd(DbItem item, int amount)
    {
        if (item?.f_item == null) throw new Exception("item can not be null");
        if (amount == 0) throw new Exception("Amount should be > 0");

        List.Clear();

        var maxStack = item.f_item.f_stack;
        return maxStack < 2 ? AddNotStackable(item, amount) : AddStackable(item, amount, maxStack);
    }

    //add stackable item 
    private static int AddStackable(DbItem item, int toAdd, int maxStack)
    {
        DbInventory.ForEachEntity(inventory => List.Add(inventory));

        //first, lets try to assign it to existing stacks
        for (var i = 0; i < List.Count && toAdd > 0; i++)
        {
            var inventoryItem = List[i].SlotItem;
            //slot is not empty
            if (inventoryItem == null) continue;
            //different item or max stack
            if (!Equals(inventoryItem.f_item, item.f_item) || inventoryItem.f_count >= maxStack) continue;
            //found a slot with the same item
            var canBeTransferred = maxStack - inventoryItem.f_count;
            if (canBeTransferred >= toAdd)
            {
                //exit point- no further actions are required
                inventoryItem.f_count += toAdd;
                if (item.f_count <= toAdd) item.Delete();
                else item.f_count -= toAdd;
                return 0;
            }

            inventoryItem.f_count += canBeTransferred;
            toAdd -= canBeTransferred;
        }

        //now we try to use empty slots
        for (var i = 0; i < List.Count && toAdd > 0; i++)
        {
            var inventorySlot = List[i];
            var inventoryItem = inventorySlot.SlotItem;
            if (inventoryItem != null) continue;
            //empty slot is found
            if (toAdd <= maxStack)
            {
                if (item.f_count <= toAdd)
                {
                    item.f_count = toAdd;
                    item.f_location = inventorySlot;
                }
                else
                {
                    item.f_count -= toAdd;
                    DbItem.NewEntity(slotItem =>
                    {
                        slotItem.f_location = inventorySlot;
                        slotItem.f_item = item.f_item;
                        slotItem.f_count = toAdd;
                    });
                }

                toAdd = 0;
            }
            else
            {
                DbItem.NewEntity(slotItem =>
                {
                    slotItem.f_location = inventorySlot;
                    slotItem.f_item = item.f_item;
                    slotItem.f_count = maxStack;
                });
                toAdd -= maxStack;
            }
        }

        return toAdd < 0 ? 0 : toAdd;
    }

    //add not stackable item  
    private static int AddNotStackable(DbItem item, int toAdd)
    {
        var freeSlots = DbInventory.FindEntities(inventory => inventory.SlotItem == null, List);
        for (var i = 0; i < freeSlots.Count && toAdd > 0; i++)
        {
            var slot = freeSlots[i];
            if (item.f_count <= 1) item.f_location = slot;
            else
            {
                DbItem.NewEntity(slotItem =>
                {
                    slotItem.f_location = slot;
                    slotItem.f_item = item.f_item;
                    slotItem.f_count = 1;
                });
                item.f_count -= 1;
            }

            toAdd--;
        }

        return toAdd;
    }
}