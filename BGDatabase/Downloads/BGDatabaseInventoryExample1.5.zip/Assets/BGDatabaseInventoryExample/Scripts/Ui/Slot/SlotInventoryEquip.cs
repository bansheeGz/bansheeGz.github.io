using UnityEngine.EventSystems;

//slot for inventory while picking items from a chest
public class SlotInventoryEquip : SlotInventory, IPointerDownHandler
{
    
     public void OnPointerDown(PointerEventData eventData)
     {
         var list = RelatedItemListUsinglocationRelation;
         var item = list.Count == 0 ? null : list[0]; 
         if (item?.f_item == null) return;
         switch (item.f_item)
         {
             case DbWeapon weapon:
             {
                 Player.Default.f_weapon = (DbInventory) Entity;
                 break;
             }
             case DbArmor armor:
             {
                 Player.Default.f_armor = (DbInventory) Entity;
                 break;
             }
             
         }
     }
 }