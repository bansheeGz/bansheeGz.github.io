using System.Collections.Generic;
using UnityEngine.EventSystems;
using UnityEngine.UI;

//slot for inventory while trading
public class SlotInventoryTrade : SlotInventory, IPointerDownHandler
{
    //serializable
    public Image priceIcon;
    public Text priceText;

    //not serializable
    private DbTrader trader;
    private static List<DbItem> reusableList = new List<DbItem>();
    
    public DbTrader Trader
    {
        set => trader = value;
    }

    private DbItem Item
    {
        get
        {
            FillRelatedItemListUsinglocationRelation(reusableList);
            return reusableList.Count == 0 ? null : reusableList[0];
        }
    }

    //this is a sell price for a player
    private int Price
    {
        get
        {
            var basePrice = Item.f_item.f_price;
            var tradeLevel = DbAbility.E_Trade.f_level;
            //we assume 5 is max level for trade
            return basePrice - basePrice / 10 * (5 - tradeLevel);
        }
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        var item = Item;
        if (Entity == null || item == null) return;

        var price = Price;
        if (trader.f_gold < price)
        {
            UiManager.ShowAlert("Trader does not have enough gold");
            return;
        }

        if (new TraderContainer(trader).TryToAdd(item))
        {
            Player.Default.f_gold += price;
            trader.f_gold -= price;
        }
        else UiManager.ShowAlert("Trader inventory is full");
    }

    public override void UpdateUi()
    {
        base.UpdateUi();

        if (EntityTyped?.SlotItem == null)
        {
            priceIcon.gameObject.SetActive(false);
            priceText.text = "";
        }
        else
        {
            priceIcon.gameObject.SetActive(true);
            priceText.text = "" + Price;
        }
    }
}