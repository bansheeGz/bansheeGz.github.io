using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

//slot for a trader
public class SlotTrade : DbGoItem, IPointerDownHandler, UiManager.IUpdatableUi
{
    public Image itemIcon;
    public Image amountIcon;
    public Text amountText;

    public Image priceIcon;
    public Text priceText;

    private SlotAbstract abstractSlot;

    //this is a buy price for a player
    private int Price
    {
        get
        {
            var basePrice = f_item.f_price;
            var tradeLevel = DbAbility.E_Trade.f_level;
            //we assume 5- is a max level for trade
            return basePrice + basePrice / 10 * (5 - tradeLevel);
        }
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        if (Entity == null || f_item == null) return;

        var traderItem = (DbItem)Entity;
        var trader = (DbTrader)f_location;

        var price = Price;
        if (price > Player.Default.f_gold)
        {
            UiManager.ShowAlert("You do not have enough gold");
            return;
        }

        var leftAmount = new InventoryContainer().TryToAdd(traderItem, 1);

        if (leftAmount != 0) UiManager.ShowAlert("Inventory is full");
        else
        {
            Player.Default.f_gold -= price;
            trader.f_gold += price;
        }
    }

    public void UpdateUi()
    {
        Utils.Assign(ref abstractSlot, () => new SlotAbstract(itemIcon, amountIcon, amountText));
        if (Entity == null || f_item == null)
        {
            abstractSlot.UpdateUi(null, 0);
            priceIcon.gameObject.SetActive(false);
        }
        else
        {
            abstractSlot.UpdateUi(f_item.f_icon, f_count);
            priceIcon.gameObject.SetActive(true);
            priceText.text = "" + Price;
        }
    }
}