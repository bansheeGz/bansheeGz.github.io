﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//equip your character (I key)
public class WindowEquip : MonoBehaviour, UiManager.IWindow, UiManager.IUpdatableUi
{
    private const int NumberOfInventorySlots = 20;

    //============ serializable
    public RectTransform inventoryPanel;
    public GameObject inventorySlotPrefab;

    public Image characterIcon;
    public Image weaponIcon;
    public Image armorIcon;
    public Text playerGold;
    public Text playerName;

    //============ not serializable
    private AbstractContainer<SlotInventory> inventory;
    private EventsManager eventsManager;

    // Start is called before the first frame update
    void Start()
    {
        //create inventory slots
        inventory = new AbstractContainer<SlotInventory>(NumberOfInventorySlots, inventoryPanel, inventorySlotPrefab, (i, slot) => slot.Entity = DbInventory.GetEntity(i));
        
        //register event listener
        eventsManager = new EventsManager(this, new EventsManager.Config
        {
            handler = UpdateUi,
            updated = new[] {DbInventory.MetaDefault.Id, DbPlayer.MetaDefault.Id},
        });

        UpdateUi();
    }

    private void OnEnable() => UpdateUi();

    private void OnDestroy() => eventsManager.Dispose();

    public void UpdateUi()
    {
        if (!gameObject.activeSelf || inventory==null) return;
        
        inventory.UpdateUi();

        var player = Player.Default;
        characterIcon.sprite = player.f_playerClass.f_icon;

        UpdateSlot(player.f_weapon, weaponIcon);
        UpdateSlot(player.f_armor, armorIcon);
        
        playerGold.text = "" + Player.Default.f_gold;
        playerName.text = Player.Default.f_name;
    }

    private void UpdateSlot(DbInventory item, Image icon)
    {
        var slotItem = item?.SlotItem;
        if (slotItem == null)
        {
            icon.sprite = null;
            icon.color = Color.clear;
        }
        else
        {
            icon.sprite = slotItem.f_item.f_icon;
            icon.color = Color.white;
        }
    }
}