﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Timers;
using BansheeGz.BGDatabase;
using UnityEngine;
using UnityEngine.UI;

//window for showing alerts
public class WindowAlert : MonoBehaviour, UiManager.IWindow
{
    private const float alertWidth = 200;

    [SerializeField] private Text alertText;

    private IEnumerator alertCoroutine;

    public void Show(string message)
    {
        gameObject.SetActive(true);
        if (alertCoroutine != null) StopCoroutine(alertCoroutine);
        StartCoroutine(alertCoroutine = ShowAlert(message));
    }


    private IEnumerator ShowAlert(string message)
    {
        alertText.text = message;
        var rect = gameObject.GetComponent<RectTransform>();
        const float animationTime = .2f;

        //show up (probably this formula is totally wrong!)
        var whileAnimation = new WhileAnimation(animationTime, elapsed => rect.localPosition = new Vector3(alertWidth * (3 - elapsed / animationTime), 70));
        while (whileAnimation.Tick) yield return null;

        //delay
        yield return new WaitForSeconds(1);

        //hide
        whileAnimation = new WhileAnimation(animationTime, elapsed => rect.localPosition = new Vector3(alertWidth * 2 + alertWidth * (elapsed / animationTime), 70));
        while (whileAnimation.Tick) yield return null;

        alertText.text = "";
        gameObject.SetActive(false);
    }

    private struct WhileAnimation
    {
        private readonly float started;
        private readonly float duration;
        private readonly Action<float> action;

        public bool Tick
        {
            get
            {
                var elapsed = Time.time - started;
                if (elapsed > duration) return false;
                action(elapsed);
                return true;
            }
        }

        public WhileAnimation(float duration, Action<float> action)
        {
            this.duration = duration;
            this.action = action;
            started = Time.time;
        }
    }
}