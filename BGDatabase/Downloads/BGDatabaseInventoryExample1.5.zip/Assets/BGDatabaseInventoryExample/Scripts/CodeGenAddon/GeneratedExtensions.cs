//manually added 

using System;
using System.Collections.Generic;
using BansheeGz.BGDatabase;

public partial class DbInventory
{
    private static readonly List<DbItem> reusableList = new List<DbItem>();
    public DbItem SlotItem
    {
        get
        {
            var items = BGCodeGenUtils.GetRelatedInbound<DbItem>(DbItem._f_location, Id, reusableList);
            if (items.Count > 1) throw new Exception("Something wrong- more than one item in the slot!");
            return items.Count ==0 ? null : items[0];
        }
    }
}