using Godot;
using System;
using BansheeGz.BGDatabase;

public partial class GoldLabel : Label
{
	public override void _Ready()
	{
		SetLabelText();
		E_Player._f_gold.ValueChanged += ValueChanged;
	}

	protected override void Dispose(bool disposing)
	{
		E_Player._f_gold.ValueChanged -= ValueChanged;
		base.Dispose(disposing);
	}

	private void ValueChanged(object sender, BGEventArgsField e) => SetLabelText();

	private void SetLabelText() => Text = "Gold: " + Player.DbPlayer.f_gold;
}
