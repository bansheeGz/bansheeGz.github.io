using Godot;
using System.IO;
using BansheeGz.BGDatabase;

public partial class Spawner : Node
{
	[Export] public string SceneName;
	public override void _Ready()
	{
		Utils.CheckDb();
		Spawn();
		AttachListeners();
	}

	protected override void Dispose(bool disposing)
	{
		DetachListeners();
		base.Dispose(disposing);
	}

	private void AttachListeners() => E_Collectable.MetaDefault.AnyEntityDeleted += CheckAllCollected;

	private void DetachListeners() => E_Collectable.MetaDefault.AnyEntityDeleted -= CheckAllCollected;

	private void CheckAllCollected(object sender, BGEventArgsAnyEntity e)
	{
		if (E_Collectable.CountEntities != 0) return;
		var random = new RandomNumberGenerator();
		E_Scene.ForEachEntity(scene =>
		{
			//number of objects to be spawned
			var count = random.RandiRange(3, 6);
			for (var i = 0; i < count; i++)
			{
				//create table row
				var newCollectable = E_Collectable.NewEntity(scene);
				//assign some gold to it
				newCollectable.f_gold = random.RandiRange(1, 10);
				//get scene area
				var bounds = scene.f_bounds;
				//assign position within that area
				newCollectable.f_position = new BansheeGz.BGDatabase.Vector2(random.RandfRange(bounds.x, bounds.xMax), random.RandfRange(bounds.y, bounds.yMax));
				//assign random type    
				newCollectable.f_type = E_CollectableType.GetEntity(random.RandiRange(0, E_CollectableType.CountEntities - 1));
			}
		});
		Spawn();
	}

	private void Spawn()
	{
		var scene = E_Scene.GetEntity(SceneName);
		scene.f_Collectable?.ForEach(obj =>
		{
			var collectible = Utils.LoadScene(E_CollectableType._f_prefab, obj.f_type).Instantiate<StaticBody2D>();
			collectible.Position = Utils.Unity2Godot(obj.f_position);
			collectible.GetNode<Gem>(".").Id = obj.Id;
			collectible.GetNode<Gem>(".").Gold = obj.f_gold;
			AddChild(collectible);
		});
	}
}
