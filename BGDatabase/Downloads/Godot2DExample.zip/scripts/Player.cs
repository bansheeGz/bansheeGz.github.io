using Godot;
using System;
using BansheeGz.BGDatabase;
using Vector2 = Godot.Vector2;

public partial class Player : CharacterBody2D, BGAddonSaveLoad.BeforeSaveReciever
{
    private float posY;
    private const float MovementSpeed = 400;
    private const float RotationSpeed = 10;
    public static E_Player DbPlayer => E_Player.GetEntity(0);
    public bool LeftMoveRequested;
    public bool RightMoveRequested;

    public override void _Ready()
    {
        Position = Utils.Unity2Godot(DbPlayer.f_position);
        posY = Position.Y;
        BGAddonSaveLoad.AddSaveReceiver(this);
    }

    protected override void Dispose(bool disposing)
    {
        BGAddonSaveLoad.RemoveSaveReceiver(this);
        base.Dispose(disposing);
    }

    public override void _PhysicsProcess(double delta)
    {
        var deltaF = (float)delta;
        if (LeftMoveRequested || Input.IsKeyPressed(Key.A)) Move(deltaF, true);
        else if (RightMoveRequested || Input.IsKeyPressed(Key.D)) Move(deltaF, false);
    }

    public void Move(float deltaF, bool left)
    {
        if (left)
        {
            Velocity = Vector2.Left * MovementSpeed;
            Rotation -= deltaF * RotationSpeed;
        }
        else
        {
            Velocity = Vector2.Right * MovementSpeed;
            Rotation += deltaF * RotationSpeed;
        }
        Move();
    }

    private void Move()
    {
        MoveAndSlide();
        var collisionCount = GetSlideCollisionCount();
        for (var i = 0; i < collisionCount; i++)
        {
            var collision = GetSlideCollision(i);
            var collider = ((Node)collision.GetCollider());
            if (collider is Gem gem)
            {
                //get db row
                var gemDb = E_Collectable.GetEntity(gem.Id);
                //increase player's gold
                DbPlayer.f_gold += gemDb.f_gold;
                //play sound FX
                var audio = GetNode<AudioStreamPlayer2D>("Audio");
                audio.Stream = Utils.LoadAudio(E_CollectableType._f_audio.GetStoredValue(gemDb.f_type.Index));
                audio.Play();
                //remove db row
                gemDb.Delete();
                //delete godot node
                gem.Free();
                //this is a tweak to keep player on the same Y position
                Position = new Vector2(Position.X, posY);
            }
            else if (collider is Teleport teleport)
            {
                GetTree().ChangeSceneToPacked(Utils.LoadScene(teleport.Scene));
            }
        }
    }
    
    public void OnBeforeSave()
    {
        DbPlayer.f_position = Utils.Godot2Unity(Position);
        var activeScene = GetTree().CurrentScene.Name;
        DbPlayer.f_scene = E_Scene.FindEntity(scene => string.Equals(scene.Name, activeScene));
    }

}