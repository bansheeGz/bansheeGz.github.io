using Godot;
using System;

public partial class MoveButton : Button
{
	[Export] public bool left;
	private Player player;

	public override void _Ready()
	{
		player = GetNode<Player>("../../player");
		if (left)
		{
			ButtonDown += () => player.LeftMoveRequested = true;
			ButtonUp += () => player.LeftMoveRequested = false;
		}
		else
		{
			ButtonDown += () => player.RightMoveRequested = true;
			ButtonUp += () => player.RightMoveRequested = false;
		}
	}
}
