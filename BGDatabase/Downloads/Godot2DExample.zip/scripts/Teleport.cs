using Godot;
using System;

public partial class Teleport : StaticBody2D
{
    [Export] public string Scene;
}
