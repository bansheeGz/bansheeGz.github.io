using Godot;
using System;
using BansheeGz.BGDatabase;

public partial class Gem : StaticBody2D
{
	public BGId Id;
	private int gold;

	public int Gold
	{
		get => gold;
		set
		{
			gold = value;
			GetNode<Label>("Label").Text = "Gold:" + value;
		}
	}
}
