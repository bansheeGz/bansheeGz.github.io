using Godot;
using System;
using BansheeGz.BGDatabase;

public partial class Gem : StaticBody2D
{
	public BGId Id;
	public int Gold
	{
		set => GetNode<Label>("Label").Text = "Gold:" + value;
	}
}
