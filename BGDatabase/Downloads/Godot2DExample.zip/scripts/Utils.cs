using Godot;
using BansheeGz.BGDatabase;
using FileAccess = Godot.FileAccess;
using Vector2 = BansheeGz.BGDatabase.Vector2;

public static partial class Utils
{
    private static bool dbLoaded;

    private const float AxisScale = 44;

    //translate from Unity world space to Godot 2d space 
    public static Godot.Vector2 Unity2Godot(Vector2 vector) => new(vector.x * AxisScale + 597, vector.y * -AxisScale + 315);

    //translate from Godot 2d space to Unity world space  
    public static Vector2 Godot2Unity(Godot.Vector2 vector) => new((vector.X - 597) / AxisScale, (vector.Y - 315) / -AxisScale);

    public static PackedScene LoadScene(BGStorable<string> field, BGEntity entity) => LoadScene(field.GetStoredValue(entity.Index));

    public static PackedScene LoadScene(string path) => ResourceLoader.Load<PackedScene>("res://scenes/" + path + ".tscn");

    //this method can be moved to startup scene 
    internal static void CheckDb()
    {
        if (dbLoaded) return;
        dbLoaded = true;
        using var file = FileAccess.Open("res://db/bansheegz_database.bytes", FileAccess.ModeFlags.Read);
        var length = (long)file.GetLength();
        var buffer = file.GetBuffer(length);
        BGRepo.SetDefaultRepoContent(buffer);
    }
}