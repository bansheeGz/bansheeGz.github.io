using System;
using Godot;
using System.IO;
using BansheeGz.BGDatabase;
using FileAccess = Godot.FileAccess;

public partial class SaveButton : Button
{
    public static string SaveFile => "user://game_save.dat";
    public override void _Pressed()
    {
        try
        {
            using var file = FileAccess.Open(SaveFile, FileAccess.ModeFlags.Write);
            var buffer = BGRepo.I.Addons.Get<BGAddonSaveLoad>().Save();
            file.StoreBuffer(buffer);
        }
        catch (Exception e)
        {
            GD.PushError(e);
        }
        
    }
}
