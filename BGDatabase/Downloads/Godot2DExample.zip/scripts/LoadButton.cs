using Godot;
using System;
using System.IO;
using BansheeGz.BGDatabase;
using FileAccess = Godot.FileAccess;

public partial class LoadButton : Button
{
	public override void _Pressed()
	{
		if (!FileAccess.FileExists(SaveButton.SaveFile)) return;
		using var file = FileAccess.Open(SaveButton.SaveFile, FileAccess.ModeFlags.Read);
		var length = (long)file.GetLength();
		var buffer = file.GetBuffer(length);
		BGRepo.I.Addons.Get<BGAddonSaveLoad>().Load(buffer);
		GetTree().ChangeSceneToPacked(Utils.LoadScene(Player.DbPlayer.f_scene.Name));
	}
}
