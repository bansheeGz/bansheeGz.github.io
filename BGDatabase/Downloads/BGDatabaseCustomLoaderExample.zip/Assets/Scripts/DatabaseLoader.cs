﻿using BansheeGz.BGDatabase;
using UnityEngine;
using UnityEngine.AddressableAssets;

//load database file from Addressables
public class DatabaseLoader : MonoBehaviour
{
    void Awake()
    {
        //we use database guid to load database file
        var databaseData = Addressables.LoadAssetAsync<TextAsset>("3637ea689da0cff4b8d5c0fb5d609c15").WaitForCompletion().bytes;
        BGRepo.SetDefaultRepoContent(databaseData);
        BGRepo.Load();
    }
}
