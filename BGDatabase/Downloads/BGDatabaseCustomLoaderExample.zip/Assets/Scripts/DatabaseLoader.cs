﻿using BansheeGz.BGDatabase;
using UnityEngine;
using UnityEngine.AddressableAssets;

//load database file from Addressables
public class DatabaseLoader : MonoBehaviour
{
    void Awake()
    {
        //we use database GUID to load database file- you can use Addressables address instead
        var databaseData = Addressables.LoadAssetAsync<TextAsset>(BGLoaderForRepoCustom.CustomDatabaseGuid).WaitForCompletion().bytes;
        BGRepo.SetDefaultRepoContent(databaseData);
        BGRepo.Load();
    }
}
