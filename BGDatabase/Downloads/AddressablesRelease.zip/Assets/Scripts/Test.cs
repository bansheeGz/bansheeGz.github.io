using UnityEngine;
using UnityEngine.AddressableAssets;

public class Test : MonoBehaviour
{
    private GameObject prefab;
    void Start() => prefab = D_Test.GetEntity(0).prefab;

    public void OnButtonClick() => Destroy(gameObject);
    private void OnDestroy() => Addressables.Release(prefab);
}
