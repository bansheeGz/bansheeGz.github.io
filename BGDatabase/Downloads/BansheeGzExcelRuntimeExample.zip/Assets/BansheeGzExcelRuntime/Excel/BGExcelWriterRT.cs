/*
<copyright file="BGExcelWriterRT.cs" company="BansheeGz">
    Copyright (c) 2019 All Rights Reserved
</copyright>
*/

using NPOI.SS.UserModel;
using NPOI.HSSF.UserModel;
using NPOI.XSSF.UserModel;

namespace BansheeGz.BGDatabase
{
    public class BGExcelWriterRT
    {
        private readonly BGLogger logger;
        private readonly BGRepo repo;
        private readonly BGRepo repoMeta;
        private readonly IWorkbook book;
        private readonly BGBookInfo bookInfo;
        private readonly BGMergeSettingsEntity entitySettings;
        private readonly BGMergeSettingsMeta metaSettings;

        public IWorkbook Book
        {
            get { return book; }
        }

        public BGExcelWriterRT(BGLogger logger, BGRepo repo, BGRepo repoMeta, BGMergeSettingsEntity entitySettings, bool useXml)
        {
            this.logger = logger;
            this.repo = repo;
            this.repoMeta = repoMeta;
            this.entitySettings = entitySettings;
            book = useXml ? (IWorkbook) new XSSFWorkbook() : new HSSFWorkbook();
            bookInfo = new BGBookInfo();
            Write();
        }

        public BGExcelWriterRT(BGLogger logger, BGRepo repo, BGRepo repoMeta, BGMergeSettingsEntity entitySettings, BGMergeSettingsMeta metaSettings, IWorkbook book, BGBookInfo bookInfo)
        {
            this.logger = logger;
            this.repo = repo;
            this.repoMeta = repoMeta;
            this.entitySettings = entitySettings;
            this.metaSettings = metaSettings;
            this.book = book;
            this.bookInfo = (BGBookInfo) bookInfo.Clone();
            Write();
        }

        private void Write()
        {
            logger.Section("Writing xls file", () =>
            {
                //entities
                new BGExcelSheetWriterEntityRT(logger, repo, book, bookInfo, entitySettings).Write();
            });
        }
    }
}