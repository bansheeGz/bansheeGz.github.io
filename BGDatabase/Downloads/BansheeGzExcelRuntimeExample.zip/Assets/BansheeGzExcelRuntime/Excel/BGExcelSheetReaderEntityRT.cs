/*
<copyright file="BGExcelSheetReaderEntityRT.cs" company="BansheeGz">
    Copyright (c) 2019 All Rights Reserved
</copyright>
*/

using System;
using NPOI.SS.UserModel;
using UnityEngine;

namespace BansheeGz.BGDatabase
{
    public class BGExcelSheetReaderEntityRT : BGExcelSheetReaderART
    {
        //================================================================================================
        //                                              Static
        //================================================================================================

        public static void ReadEntities(IWorkbook book, BGBookInfo info, BGRepo repo, BGLogger logger, bool ignoreNew)
        {
            logger.AppendLine("Reading entities: iterating sheets..");
            for (var i = 0; i < book.NumberOfSheets; i++)
            {
                var sheet = book.GetSheetAt(i);

                if (logger.AppendWarning(string.IsNullOrEmpty(sheet.SheetName), "Sheet with empty name at index $", i)) continue;


                logger.SubSection(() =>
                {
                    if (logger.AppendWarning(!repo.HasMeta(sheet.SheetName), "Sheet [$] is skipped. No meta with such name found.", sheet.SheetName)) return;

                    var meta = repo[sheet.SheetName];
                    if (logger.AppendWarning(info.HasEntitySheet(meta.Id), "Sheet [$] is skipped. Duplicate name, sheet with the same name already been processed.", sheet.SheetName)) return;

                    BGExcelSheetReaderEntityRT reader;
                    if (sheet.PhysicalNumberOfRows == 0)
                    {
                        logger.AppendLine("Sheet [$] is mapped ok, but no rows found.", sheet.SheetName);
                        reader = new BGExcelSheetReaderEntityRT(i, meta, ignoreNew);
                    }
                    else
                    {
                        logger.AppendLine("Sheet [$] is mapped ok. $ rows found.", sheet.SheetName, sheet.LastRowNum + 1);
                        var headersRow = sheet.GetRow(0);
                        reader = new BGExcelSheetReaderEntityRT(i, meta, ignoreNew, headersRow, logger);
                    }

                    info.AddEntitySheet(meta.Id, reader.Info);

                    if (logger.AppendWarning(!reader.Info.HasAnyData, "No columns found for Sheet [$].", sheet.SheetName)) return;

                    // read data
                    var count = 0;
                    var existingCount = 0;
                    var newCount = 0;
                    ForEachRowNoHeader(sheet, row =>
                    {
                        count++;
                        reader.Read(row, ref existingCount, ref newCount);
                    });
                    logger.AppendLine("Read $ rows. $ existing entities. $ new entities. $ rows are skipped.", count, existingCount, newCount, count - existingCount - newCount);
                }, "Reading sheet $", sheet.SheetName);
            }
        }

        //================================================================================================
        //                                              Fields
        //================================================================================================

        private readonly BGMetaEntity meta;
        private readonly BGEntitySheetInfo info;
        private readonly BGLogger logger;
        private readonly bool ignoreNew;


        public BGEntitySheetInfo Info
        {
            get { return info; }
        }

        //================================================================================================
        //                                              Constructors
        //================================================================================================

        public BGExcelSheetReaderEntityRT(int sheetNumber, BGMetaEntity meta, bool ignoreNew)
        {
            this.meta = meta;
            this.ignoreNew = ignoreNew;
            info = new BGEntitySheetInfo(meta.Id, meta.Name, sheetNumber);
        }

        public BGExcelSheetReaderEntityRT(int sheetNumber, BGMetaEntity meta, bool ignoreNew, IRow headersRow, BGLogger logger) : this(sheetNumber, meta, ignoreNew)
        {
            this.logger = logger;

            logger.SubSection(() =>
            {
                info.PhysicalColumnCount = headersRow.Cells.Count;

                ForEachCell(headersRow, (i, cell) =>
                {
                    if (logger.AppendWarning(cell.CellType != CellType.String, "[$]->[error:not a string],", i)) return;

                    var name = cell.StringCellValue;
                    var index = cell.ColumnIndex;

                    if (logger.AppendWarning(string.IsNullOrEmpty(name), "[$]->[error:empty string],", i)) return;

                    switch (name)
                    {
                        case BGBookInfo.IdHeader:
                            //id
                            logger.AppendLine("[$]->[_id],", i);
                            info.IndexId = index;
                            break;
                        default:
                            //field
                            var field = meta.GetField(name, false);
                            if (logger.AppendWarning(field == null, "[$]->[error:no field],", i)) return;

                            logger.AppendLine("[$]->[$],", i, field.Name);
                            info.AddField(field.Id, index);
                            break;
                    }
                });
            }, "Mapping for [$]", meta.Name);
        }

        //================================================================================================
        //                                              Read a row
        //================================================================================================

        public void Read(IRow row, ref int existingCount, ref int newCount)
        {
            if (row == null) return;
            if (row.RowNum == 0) return;

            //----------- id
            var entityId = BGId.Empty;
            if (info.IndexId >= 0)
            {
                ReadNotNull(row, info.IndexId, s =>
                {
                    try
                    {
                        entityId = new BGId(s);
                        //duplicate entity
                        if (info.HasRow(entityId)) throw new BGDBTextProcessor.ExitException();
                        info.AddRow(entityId, row.RowNum);
                    }
                    catch (BGDBTextProcessor.ExitException)
                    {
                        logger.AppendWarning("Duplicate entity found. id=$", s);
                        throw;
                    }
                    catch (Exception e)
                    {
                        logger.AppendWarning("Exception while trying to fetch entity with id=$. Error=$", s, e.Message);
                        throw new BGDBTextProcessor.ExitException();
                    }
                });
            }

            if (entityId == BGId.Empty && ignoreNew) return;

            BGEntity entity = null;
            var newEntity = false;
            //------ fields
            info.ForEachField((id, column) =>
            {
                if (entity == null)
                {
                    entity = EnsureEntity(row, entityId);
                    newEntity = entityId == BGId.Empty;
                }

                var field = meta.GetField(id);
                ReadNotNull(row, column, s =>
                {
                    try
                    {
                        field.FromString(entity.Index, s);
                    }
                    catch (Exception e)
                    {
                        Debug.Log(BGUtil.Format("Can not fetch field $ value for entity with id=$. Value=$. Error=$", field.Name, entityId, s, e.Message));
                        logger.AppendWarning("Can not fetch field $ value for entity with id=$. Value=$. Error=$", field.Name, entityId, s, e.Message);
                    }
                });
            });

            if (entity != null)
            {
                if (newEntity) newCount++;
                else existingCount++;
            }
        }

        private BGEntity EnsureEntity(IRow row, BGId entityId)
        {
            // create an entity if required
            BGEntity entity;
            if (entityId != BGId.Empty)
            {
                //--------------------  existing entity
                entity = meta.NewEntity(entityId);
            }
            else
            {
                //-------------------- new entity
                entity = meta.NewEntity();
                if (info.IndexId >= 0)
                {
                    //update id if idcolumn exists
                    var idCell = row.GetCell(info.IndexId) ?? row.CreateCell(info.IndexId);
                    idCell.SetCellType(CellType.String);
                    idCell.SetCellValue(entity.Id.ToString());
                }
            }

            return entity;
        }
    }
}