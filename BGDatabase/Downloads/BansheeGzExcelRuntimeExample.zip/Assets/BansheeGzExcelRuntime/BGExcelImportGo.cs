﻿/*
<copyright file="BGExcelImportGo.cs" company="BansheeGz">
    Copyright (c) 2019 All Rights Reserved
</copyright>
*/

using System;
using System.IO;
using System.Threading;
using UnityEngine;

namespace BansheeGz.BGDatabase
{
    /// <summary>
    /// This class adds runtime support for importing/exporting data from/to Excel file 
    /// </summary>
    public class BGExcelImportGo : MonoBehaviour
    {
        //================================ serializable
        [Tooltip("If path is rooted, absolute path is used, if path is relative, StreamingAssets folder is used as parent folder")]
        public string ExcelFile = "c:/excel.xls";

        [Tooltip("Coordinates for GUI position")]
        public Vector2 UICoordinates = new Vector2(10, 10);
        
        [Tooltip("If set to true, data will be imported in Start method")]
        public bool ImportOnStart;
        
        [Tooltip("If set to true, target xls file will be monitored and it it's changed, data will be imported")]
        public bool MonitorFile;
        
        [Tooltip("If set to true, export will ignore all tables which does not have corresponding sheet in target xls file")]
        public bool ExportMetaOnlyIfSheetExists;
        
        [Tooltip("If set to true, custom GUI will not be shown and you will need to call Import/Export methods from your own scripts in case you want to manually trigger import/export function")]
        public bool DisableGUI;

        //================================  not serializable
        private bool expanded;
        private string error;
        private long lastRun;
        private long monitoredTime;
        private Texture2D blackTexture;
        private ThreadMonitor threadMonitor;
        private readonly ThreadMonitor importMonitor = new ThreadMonitor();
        private string lastLog;
        private int warnings;
        private Vector2 scrollPosition;
        private readonly object fileNameLock = new object();

        private FileInfo SettingsFile
        {
            get { return new FileInfo(Path.Combine(Application.persistentDataPath, "excel_settings.json")); }
        }

        private string ExcelFileSynced
        {
            get
            {
                lock (fileNameLock) return ExcelFile;
            }
            set
            {
                lock (fileNameLock) ExcelFile = value;
            }
        }

        private string ExcelFilePath
        {
            get
            {
                var path = ExcelFileSynced;
                if (string.IsNullOrEmpty(path)) return "";
                if (!Path.IsPathRooted(path)) path = Path.Combine(Application.streamingAssetsPath, path);
                return path;
            }
        }

        void Start()
        {
            monitoredTime = DateTime.Now.Ticks;
            LoadSetting();
            if (ImportOnStart) Import();
            CheckMonitor();
        }

        private void Update()
        {
            if (!importMonitor.ActionRequested) return;
            importMonitor.ActionRequested = false;
            Import();
        }

        private void OnDestroy()
        {
            TerminateThread();
        }

        private void OnGUI()
        {
            if (DisableGUI) return;
            if (GUI.Button(new Rect(UICoordinates, new Vector2(80, 19)), expanded ? "Excel <<" : "Excel >>")) expanded = !expanded;
            if (!expanded) return;


            //-------------- expanded
            var fileExist = File.Exists(ExcelFilePath);
            Area(new Rect(UICoordinates + new Vector2(0, 19), new Vector2(500, 440)), () =>
            {
                Form("File", () =>
                {
                    var oldPath = ExcelFileSynced;
                    var newValue = GUILayout.TextField(oldPath);
                    if (!string.Equals(newValue, oldPath)) ExcelFileSynced = newValue;
                });
                Form("Import OnStart", () => BoolField(ref ImportOnStart));
                Form("Monitor file", () => BoolField(ref MonitorFile, CheckMonitor));
                Form("Export meta only if sheet exists", () => BoolField(ref ExportMetaOnlyIfSheetExists));
                Form("File exist? ", () => Choice(fileExist, "Yes", "No", Color.green, Color.red));
                Form("File modified", () => GUILayout.Label(lastRun == 0 ? "N/A" : new DateTime(lastRun).ToString("MM/dd/yyyy HH:mm:ss")));
                Form("Last run since game started", () => GUILayout.Label(lastRun == 0 ? "N/A" : new DateTime(lastRun).ToString("MM/dd/yyyy HH:mm:ss")));
                Form("Settings file", () => GUILayout.Label(File.Exists(SettingsFile.FullName) ? "exists" : "not exists"));
                Form("Error during run", () =>
                {
                    if (error == null) GUILayout.Label("N/A");
                    else GUILayout.Label(error, new GUIStyle {normal = {textColor = Color.red}, wordWrap = true}, GUILayout.Height(21 * 3));
                });
                Horizontal(() =>
                {
                    Choice(warnings == 0, "Warnings", "Warnings", Color.white, Color.red);
                    Choice(warnings == 0, "0", "" + warnings, Color.green, Color.red);
                });
                Horizontal(() =>
                {
                    if (GUILayout.Button("Save settings")) SaveSetting();
                    if (GUILayout.Button("Delete settings")) DeleteSetting();
                    if (GUILayout.Button("Export now")) Export();
                    if (GUILayout.Button("Import now")) Import();
                });
                scrollPosition = GUILayout.BeginScrollView(scrollPosition);
                GUILayout.TextArea(lastLog, new GUIStyle {richText = true});
                GUILayout.EndScrollView();
            });
        }

        private void CheckMonitor()
        {
            TerminateThread();
            if (MonitorFile) new Thread(BackgroundMonitoring) {IsBackground = true}.Start(threadMonitor = new ThreadMonitor());
            else threadMonitor = null;
        }

        private void TerminateThread()
        {
            if (threadMonitor != null) threadMonitor.ActionRequested = true;
        }

        private void BackgroundMonitoring(object parameter)
        {
            // print("monitor thread started");
            var monitor = (ThreadMonitor) parameter;
            while (true)
            {
                if (monitor.ActionRequested) break;
                Thread.Sleep(500);
                if (monitor.ActionRequested) break;
                var excelFilePath = ExcelFilePath;
                if (!File.Exists(excelFilePath)) continue;
                var lastWritten = File.GetLastWriteTime(excelFilePath).Ticks;
                if (monitoredTime < lastWritten)
                {
                    monitoredTime = lastWritten;
                    importMonitor.ActionRequested = true;
                }
            }

            // print("monitor thread terminated");
        }


        private void LoadSetting()
        {
            var file = SettingsFile;
            if (!file.Exists) return;
            var json = JsonUtility.FromJson<JsonSettings>(File.ReadAllText(file.FullName));
            ExcelFileSynced = json.file;
            ImportOnStart = json.autoRun;
            MonitorFile = json.monitorFile;
            ExportMetaOnlyIfSheetExists = json.exportMetaOnlyIfSheetExists;
        }

        private void SaveSetting()
        {
            File.WriteAllText(SettingsFile.FullName, JsonUtility.ToJson(new JsonSettings
            {
                file = ExcelFileSynced,
                monitorFile = MonitorFile,
                autoRun = ImportOnStart,
                exportMetaOnlyIfSheetExists = ExportMetaOnlyIfSheetExists,
            }));
        }

        private void DeleteSetting()
        {
            var file = SettingsFile;
            if (!file.Exists) return;
            File.Delete(file.FullName);
        }

        public void Export()
        {
            lastRun = DateTime.Now.Ticks;
            error = null;
            warnings = 0;
            lastLog = null;

            try
            {
                var logger = new BGExcelExportManager().Export(ExcelFilePath, ExportMetaOnlyIfSheetExists);
                warnings = logger.Warnings;
                lastLog = logger.Log;
            }
            catch (Exception e)
            {
                Debug.LogException(e);
                error = e.Message;
                lastLog = e.ToString();
            }
        }

        public void Import()
        {
            lastRun = DateTime.Now.Ticks;
            error = null;
            warnings = 0;
            lastLog = null;

            try
            {
                var logger = new BGExcelImportManager().Import(ExcelFilePath);
                warnings = logger.Warnings;
                lastLog = logger.Log;
		var binders = Resources.FindObjectsOfTypeAll<BGDataBinderGoA>();
                if (binders != null)
                {
                    foreach (var binder in binders) binder.Bind();
                }
            }
            catch (Exception e)
            {
                Debug.LogException(e);
                error = e.Message;
                lastLog = e.ToString();
            }
        }

        private void Horizontal(Action action)
        {
            GUILayout.BeginHorizontal();
            action();
            GUILayout.EndHorizontal();
        }

        private void Area(Rect rect, Action action)
        {
            if (blackTexture == null)
            {
                blackTexture = new Texture2D(1, 1);
                blackTexture.SetPixel(0, 0, new Color(0, 0, 0, .4f));
                blackTexture.Apply();
            }

            GUI.DrawTexture(rect, blackTexture);
            GUILayout.BeginArea(rect);
            action();
            GUILayout.EndArea();
        }

        private void Form(string label, Action action)
        {
            Horizontal(() =>
            {
                GUILayout.Label(label, GUILayout.Width(200));
                action();
            });
        }

        private void BoolField(ref bool value, Action action = null)
        {
            var newValue = GUILayout.Toggle(value, "");
            if (newValue == value) return;

            value = newValue;
            if (action != null) action();
        }

        private void Choice(bool condition, string option1, string option2, Color color1, Color color2)
        {
            if (condition) GUILayout.Label(option1, new GUIStyle {normal = {textColor = color1}});
            else GUILayout.Label(option2, new GUIStyle {normal = {textColor = color2}});
        }

        [Serializable]
        private class JsonSettings
        {
            public string file;
            public bool autoRun;
            public bool monitorFile;
            public bool exportMetaOnlyIfSheetExists;
        }

        private class ThreadMonitor
        {
            private int actionRequested;

            public bool ActionRequested
            {
                get { return (Interlocked.CompareExchange(ref actionRequested, 1, 1) == 1); }
                set
                {
                    if (value) Interlocked.CompareExchange(ref actionRequested, 1, 0);
                    else Interlocked.CompareExchange(ref actionRequested, 0, 1);
                }
            }
        }
    }
}