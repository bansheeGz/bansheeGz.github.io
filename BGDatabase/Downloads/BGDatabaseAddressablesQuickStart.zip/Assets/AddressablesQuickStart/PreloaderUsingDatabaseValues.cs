﻿using BansheeGz.BGDatabase;
using UnityEngine.SceneManagement;

//preload "addressable" field (using addresses from BGDatabases) and load target scene, called "scene"
public class PreloaderUsingDatabaseValues : BGAddressablesPreloader
{
    protected override bool IsIncluded(BGField field)
    {
        //we will preload only E_Prefabs._f_addressable field
        return E_Prefabs._f_addressable.Equals(field);
    }

    public override void Completed()
    {
        SceneManager.LoadScene("scene");
    }
}
