﻿using System.Collections.Generic;
using BansheeGz.BGDatabase.Example;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

//preload all resources and load target scene, called "scene", using addresses from BGDatabases
public class PreloaderUsingDatabaseValues : MonoBehaviour
{
    void Start()
    {
        var addresses = new List<object>();
        
        //iterate all rows of "Prefabs" table and gather all addresses from "addressable" field 
        E_Prefabs.ForEachEntity(entity => addresses.Add(E_Prefabs._f_addressable.GetStoredValue(entity.Index)));
        
        //load assets using addresses
        var asyncOperation = Addressables.LoadAssetsAsync<Object>(addresses, null, Addressables.MergeMode.Union);
        asyncOperation.Completed += operation =>
        {
            //all assets are ready to use- load target scene
            SceneManager.LoadScene("scene");
        };
    }

}
