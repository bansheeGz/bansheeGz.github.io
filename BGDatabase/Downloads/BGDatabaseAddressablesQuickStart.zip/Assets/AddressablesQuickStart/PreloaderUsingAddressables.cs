﻿using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.SceneManagement;

//preload all resources and load target scene, called "scene", using Addressables system's label "MyScene"
public class PreloaderUsingAddressables : MonoBehaviour
{
    void Start()
    {
        var asyncOperation = Addressables.LoadAssetsAsync<Object>("MyScene", null);
        asyncOperation.Completed += operation =>
        {
            //all assets are ready to use- load target scene
            SceneManager.LoadScene("scene");
        };
    }
}
