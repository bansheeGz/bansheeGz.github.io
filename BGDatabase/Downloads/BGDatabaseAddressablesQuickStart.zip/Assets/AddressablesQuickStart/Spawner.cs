﻿using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.ResourceProviders;

public class Spawner : MonoBehaviour
{
    void Start()
    {
        //Technique # 1: use generated Load{FieldName}Async method
        E_Prefabs.GetEntity(0).Loadf_addressableAsync(prefab => Instantiate(prefab));

        //Technique # 2: use generated property for synchronous loading (Addressables 1.17.17 added support for sync loading)
        Instantiate(E_Prefabs.GetEntity(1).f_addressable, Vector3.right * 2, Quaternion.identity);

        //Technique # 3: using raw addressables address with Addressables
        Addressables.InstantiateAsync(E_Prefabs._f_addressable.GetAddressablesAddress(2), new InstantiationParameters(Vector3.right * 4, Quaternion.identity, null));
    }
}