﻿using System;
using BansheeGz.BGDatabase.Example;
using UnityEngine;
using UnityEngine.AddressableAssets;

public class Spawner : MonoBehaviour
{
    
    void Start()
    {
        SpawnPreLoaded();
        SpawnByAddresses();
    }

    // Spawn all prefabs from "Prefabs" table, field "addressables", usual way (by reading field values)
    private void SpawnPreLoaded()
    {
        try
        {
            var counter = 0;
            //if you are using usual method for reading assets (entity.f_prefabAddressables), these assets needs to be preloaded
            E_Prefabs.ForEachEntity(entity => Instantiate(entity.f_addressable, Vector3.right * counter++, Quaternion.identity));
            print("Pre-loaded assets are created ok.");
        }
        catch (ArgumentException)
        {
            print("Unable to instantiate pre-loaded assets");
        }
    }
    
    // Spawn all prefabs from "Prefabs" table, field "addressablesByGuid", using asset addresses
    private void SpawnByAddresses()
    {
        var counter = 0;
        //if you are using usual addresses (BGStorable<string>.GetStoredValue(entity.Index)), you can use these addresses directly with addressables system
        E_Prefabs.ForEachEntity(entity => Addressables.InstantiateAsync(
            E_Prefabs._f_addressableByGuid.GetAddressablesAddress(entity.Index), 
            Vector3.right * counter++ + Vector3.up * 3, 
            Quaternion.identity)
        );
        print("Assets, retrieved by addresses, are created ok.");
    }

}