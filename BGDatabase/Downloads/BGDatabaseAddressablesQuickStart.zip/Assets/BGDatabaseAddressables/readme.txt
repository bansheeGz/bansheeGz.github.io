BGDatabase Addressables plugin by BancheeGz, (c) 2018-2020 
Version: 1.3
Release date: 05 Aug 2020
Home page: https://www.bansheegz.com/BGDatabase/Downloads/RuntimeAddressables/
